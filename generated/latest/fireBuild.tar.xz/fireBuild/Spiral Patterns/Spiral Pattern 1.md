---
title: Spiral Pattern 1
---

# Spiral Pattern 1

![Spiral Pattern 1](/assets/patterns/spiral/spiralpattern1.jpg)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/spiral/spiralpattern1.cpp"
#include <iostream>
using namespace std;

void printSpiral(int size)
{
    int row = 0, col = 0;

    int boundary = size - 1;
    int sizeLeft = size - 1;
    int flag = 1;
    char move = 'r';

    int matrix[size][size] = {0};

    for (int i = 1; i < size * size + 1; i++) {
        matrix[row][col] = i;

        switch (move) {
            case 'r':
                col += 1;
                break;

            case 'l':
                col -= 1;
                break;

            case 'u':
                row -= 1;
                break;

            case 'd':
                row += 1;
                break;
        }

        if (i == boundary) {
            boundary += sizeLeft;

            if (flag != 2)
                flag = 2;
            else {
                flag = 1;
                sizeLeft -= 1;
            }

            switch (move) {
                case 'r':
                    move = 'd';
                    break;

                case 'd':
                    move = 'l';
                    break;

                case 'l':
                    move = 'u';
                    break;

                case 'u':
                    move = 'r';
                    break;
            }
        }
    }

    for (row = 0; row < size; row++) {
        for (col = 0; col < size; col++) {

            int n = matrix[row][col];
            if (n < 10)
                cout << "0" << n << " ";
            else
                cout << n << " ";
        }

        cout << endl;
    }
}

int main()
{
    int size = 5;
    printSpiral(size);
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/spiral/spiralpattern1.py"
n = 5  # size

# array with zero fill
arr = [[0 for x in range(n)] for x in range(n)]

x=0
y=0
z=1

for ot in range((n // 2)+1):
    if ot == n // 2:
        z -= 1

    for j in range(y, n - y):
        arr[x][j] = z
        z += 1

    for i in range(x + 1, n - x - 1):
        arr[i][n - y - 1] = z
        z += 1

    for j in range(n - y - 1, y-1,-1):
        arr[n - x - 1][j] = z
        z += 1

    for i in range(n-x-2,x,-1):
        arr[i][y] = z
        z += 1

    x+=1
    y+=1

for a in range(n):
    for b in range(n):
        print("{:02d} ".format(arr[a][b]), end="")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
