---
title: Spiral Pattern 4
---

# Spiral Pattern 4

![Spiral Pattern 4](/assets/patterns/spiral/spiralpattern4.jpg)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/spiral/spiralpattern4.cpp"
#include <iostream>
using namespace std;

int main()
{
    int size = 5;
    
    int row = 0, col = 0;

    int boundary = size*size - 3;
    int sizeLeft = size - 1;
    int flag = 1;
    char move = 'r';

    int matrix[size][size] = {0};

    for (int i = size*size; i > 0; i--) {
        matrix[row][col] = i;

        switch (move) {
            case 'r':
                col += 1;
                break;

            case 'l':
                col -= 1;
                break;

            case 'u':
                row -= 1;
                break;

            case 'd':
                row += 1;
                break;
        }

        if (i == boundary) {
            boundary -= sizeLeft;

            if (flag != 2)
                flag = 2;
            else {
                flag = 1;
                sizeLeft -= 1;
            }

            switch (move) {
                case 'r':
                    move = 'd';
                    break;

                case 'd':
                    move = 'l';
                    break;

                case 'l':
                    move = 'u';
                    break;

                case 'u':
                    move = 'r';
                    break;
            }
        }
    }

    for (row = 0; row < size; row++) {
        for (col = 0; col < size; col++) {

            int n = matrix[row][col];
            if (n < 10)
                cout << "0" << n << " ";
            else
                cout << n << " ";
        }

        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/spiral/spiralpattern4.py"
i = 1
rows = 10
k = 1

for x in range(1, rows * 2 + 1, +2):
    if k % 2 == 1:
        print("{:02d} ".format(i), end="")
        print("{:02d} ".format(i + 1), end="")
        print("{:02d} ".format(i + 2), end="")
        print("{:02d} ".format(i + 3), end="")
        k += 1
        i += 4
    else:
        print("{:02d} ".format(i + 3), end="")
        print("{:02d} ".format(i + 2), end="")
        print("{:02d} ".format(i + 1), end="")
        print("{:02d} ".format(i), end="")
        k += 1
        i += 4
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
