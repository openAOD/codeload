---
title: Wave Pattern 12
---

# Wave Pattern 12

![Wave Pattern 12](/assets/patterns/wave/wavepattern12.jpg)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/wave/wavepattern12.cpp"
#include <iostream>
using namespace std;

int main() 
{
    int height = 4, length = 4;
    int x = height - 1;
    char ch;
    for(int i = 0; i <= height; i++) {
        ch = 'A';
        for(int j = 0; j < height*length*2; j++) {
            if(j % (height*2) == x || j % (height*2) == height + i)
                cout << ch << " ";
            else
                cout << " ";
            ch++;
            if(ch > 'Z')
                ch = ch - 26;
        }
        x--;
        cout << endl;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/wave/wavepattern12.py"
wH = 4  # 1
wL = 4  # 2
pc = wH - 1  # 3

for x in range(0, wH + 1):
    pchar = ord('A')  # 4
    for y in range(0, (wH * wL * 2)):
        if (y % (wH * 2) == pc or
                y % (wH * 2) == wH + x):
            print(chr(pchar), end="")
        else:
            print(" ", end="")  # single space
        pchar += 1  # 5
        if (pchar > ord('Z')):  # 6
            pchar = pchar - 26  # 7
    pc -= 1
    print()

    """
1) change value to increase/decrease the height of the wave
2) change value to increase/decrease the length of the wave
3) cond for printing
4) set printing character
5) increment print char
6) reset print char to 'A'
    """
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
