---
title: Wave Pattern 23
---

# Wave Pattern 23

![Wave Pattern 23](/assets/patterns/wave/wavepattern23.jpg)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/wave/wavepattern23.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() 
{
    int height = 4, length = 3;
    int num = height + 1, inc = 1, x = 0;
    int jump = (num*3 + 2) - (num + 3);
    
    for(int i = 1; i <= height; i++) {
        for(int j = 1; j <= length; j++) {
            if(i != height)
                cout << "   ";
            else
                cout << setfill('0') << setw(2) << num - 1 << " "; 
            
            for(int k = 1; k <= 4; k++) {
                if(i == 1 || k == 1 || k == 4) {
                    cout << setfill('0') << setw(2) << num << " "; 
                    num += inc;
                }
                else
                    cout << "   ";
            }
            num -= inc;
            
            if(i != height)
                cout << "   ";
            else
                cout << setfill('0') << setw(2) << num + 1 << " ";
            num += jump;
        }
        jump -= 2;
        inc = 5 + x;
        x += 2;
        num = height - i + 1;
        
        cout << endl;
    } 
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/wave/wavepattern23.py"
wH = 4  # 1
wL = 4  # 2
num = wH + 1
jump = (num * 3 + 2) - (num + 3)
inc = 1
m = 0

for x in range(1, wH + 1):
    for y in range(1, wL + 1):
        if (x != wH):
            print("   ", end="")  # 3
        else:
            print("{:02d} ".format(num - 1), end="")
        for z in range(1, 5):
            if (x == 1 or z == 1 or z == 4):
                print("{:02d} ".format(num), end="")
                num += inc
            else:
                print("   ", end="")  # 3
        num -= inc  # 4
        if (x != wH):
            print("   ", end="")  # 3
        else:
            print("{:02d} ".format(num + 1), end="")
        num += jump
    jump -= 2
    inc = 5 + m
    m += 2
    num = wH - x + 1
    print()

    """
1) wH - change value to increase/decrease the height of the wave
2) wL - change value to increase/decrease the length of the wave
3) 3 whitespaces
4) restore value of num 

    """
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
