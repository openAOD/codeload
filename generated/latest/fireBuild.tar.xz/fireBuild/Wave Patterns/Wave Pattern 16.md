---
title: Wave Pattern 16
---

# Wave Pattern 16

![Wave Pattern 16](/assets/patterns/wave/wavepattern16.jpg)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/wave/wavepattern16.cpp"
#include <iostream>
using namespace std;

int main() 
{
    int height = 5, length = 4;
    int inSpace = 1, outSpace = 2;
    for(int i = 1; i <= height; i++) {
        for(int j = 1; j <= length; j++) {
            for(int k = 1; k <= outSpace; k++)
                cout << " ";
            cout << "0";
            for(int k = 1; k <= inSpace; k++)
                cout << " ";
            cout << "0";
            for(int k = 1; k <= outSpace; k++)
                cout << " ";
            cout << " ";
        }
        outSpace = (i + 1 != height);
        inSpace = (i + 1 != height) ? 3 : 5;
        cout << endl;
    } 
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/wave/wavepattern16.py"
wH = 5  # 1
wL = 4  # 2
insp = 1  # 3
ousp = 2  # 4

for x in range(1, wH + 1):
    for y in range(1, wL + 1):
        for z in range(1, ousp + 1):
            print(" ", end="")
        print("0", end="")  # any symbol
        for z in range(1, insp + 1):
            print(" ", end="")
        print("0", end="")  # any symbol
        for z in range(1, ousp + 1):
            print(" ", end="")
        print(" ", end="")

    ousp = (x + 1 != wH)  # 5

    if (x + 1 != wH):  # 6
        insp = 3
    else:
        insp = 5
    print()

    """
1) wH - change value to increase/decrease the height of the wave
2) wL - change value to increase/decrease the length of the wave
3) inner space
4) outer space
5) set value of ousp to 1 if x+1 is not equal to wave height (wH) or 0 otherwise
6) set value of insp to 3 if x+1 is not equal to wave height (wH) or 5 otherwise
    """
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
