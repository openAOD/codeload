---
title: Wave Pattern 24
---

# Wave Pattern 24

![Wave Pattern 24](/assets/patterns/wave/wavepattern24.jpg)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/wave/wavepattern24.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() 
{
    int height = 5, length = 2;
    
    for(int i = 1; i <= height; i++) {
        for(int j = 1; j <= length; j++) {
            if(i != height)
                cout << "##";
            else
                cout << "  "; 
            
            for(int k = 1; k <= 4; k++) {
                if(i == 1 || k == 1 || k == 4) 
                    cout << "  ";
                else
                    cout << "##";
            }
            
            if(i != height)
                cout << "##";
            else
                cout << "  ";
        }
        cout << endl;
    } 
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/wave/wavepattern24.py"
wH = 4  # 1
wL = 4  # 2

for x in range(1, wH + 1):
    for y in range(1, wL + 1):
        if (x != wH):
            print("##", end="")
        else:
            print("  ", end="")  # 3
        for z in range(1, 5):
            if (x == 1 or z == 1 or z == 4):
                print("  ", end="")  # 3
            else:
                print("##", end="")

        if (x != wH):
            print("##", end="")
        else:
            print("  ", end="")  # 3
    print()

    """
1) wH - change value to increase/decrease the height of the wave
2) wL - change value to increase/decrease the length of the wave
3) 2 whitespaces

    """
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
