---
title: Wave Pattern 10
---

# Wave Pattern 10

![Wave Pattern 10](/assets/patterns/wave/wavepattern10.jpg)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/wave/wavepattern10.cpp"
#include <iostream>
using namespace std;

int main() 
{
    int height = 4, length = 4;
    int x = height - 1;
    for(int i = 0; i <= height; i++) {
        for(int j = 0; j < height*length*2; j++) {
            if(j % (height*2) == x || j % (height*2) == height + i)
                cout << "*";
            else
                cout << " ";
        }
        x--;
        cout << endl;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/wave/wavepattern10.py"
wH = 4  # 1
wL = 4  # 2
pc = wH - 1  # 3

for x in range(0, wH + 1):
    for y in range(0, (wH * wL * 2)):
        if (y % (wH * 2) == pc or
                y % (wH * 2) == wH + x):
            print("*", end="")
        else:
            print(" ", end="")  # single space
    pc -= 1
    print()

    """
1) change value to increase/decrease the height of the wave
2) change value to increase/decrease the length of the wave
3) cond for printing
    """
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
