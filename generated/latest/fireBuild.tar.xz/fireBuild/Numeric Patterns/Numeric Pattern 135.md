---
title: Numeric Pattern 135
---

# Numeric Pattern 135

![Numeric Pattern 135](/assets/patterns/numeric/numericpattern135.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern135.cpp"
#include <iostream>
#include <math.h>
using namespace std;

bool isPrime(int n){
    for(int i=2; i<n; i++)
        if(n%i==0)
            return false;

    return true;
}

int main(){

    int n=5;

    int k=2;
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            while(!isPrime(k)){
                k++;
            }
            cout<<k++<<" ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
