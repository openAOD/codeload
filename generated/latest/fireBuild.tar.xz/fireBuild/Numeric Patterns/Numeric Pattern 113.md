---
title: Numeric Pattern 113
---

# Numeric Pattern 113

![Numeric Pattern 113](/assets/patterns/numeric/numericpattern113.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern113.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=5;

    for(int i=0; i<n; i++){
        for(int j=0; j<i; j++){
            cout<<"  ";
        }
        for(int j=0; j<(2*(n-i))-1; j++){
            cout<<n-i<<" ";
        }

        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern113.java"
/**
 * 
 * pattern to be printed 
 * 
 *  5 5 5 5 5 5 5 5 5
 *    4 4 4 4 4 4 4
 *      3 3 3 3 3
 *        2 2 2
 *          1
 * 
 * numericpattern113
 */
public class numericpattern113 {

    public static void main(String[] args) {
        int rows = 5;
        numericPattern113(rows);
    }
    private static void numericPattern113(int n) {
        n+=1;
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <=  i; j++) {
                System.out.print("  ");
            }
        
            for (int j = 1; j <= 2* (n-i) -1; j++) {
                System.out.print((n-i) + " ");
                
            }
            System.out.println();
        }

    }

}
```
