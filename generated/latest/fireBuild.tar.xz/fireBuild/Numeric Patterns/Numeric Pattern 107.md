---
title: Numeric Pattern 107
---

# Numeric Pattern 107

![Numeric Pattern 107](/assets/patterns/numeric/numericpattern107.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern107.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=5;

    int k=1;
    for(int i=0; i<n; i++){
        for(int j=0; j<n-i; j++){
            cout<<"  ";
        }
        for(int j=0; j<i; j++){
            cout<<pow(2,j)<<" ";
        }
        for(int j=i; j>=0; j--){
            cout<<pow(2,j)<<" ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern107.java"

/**
 * 
 * pattern to be printed 
 * 
 *          1
 *        1 2 1
 *      1 2 4 2 1
 *    1 2 4 8 4 2 1
 *  1 2 4 8 16 8 4 2 1
 * 
 * 
 * numericpattern107
 */

import java.lang.Math;

public class numericpattern107 {
    public static void main(String[] args) {

        int rows = 5;
        numericPattern107(rows);
    }

    private static void numericPattern107(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= n - i; j++) {
                System.out.print("  ");
            }
            for (int j = 1; j <=  i ; j++) {
                System.out.print((int)Math.pow(2, j-1) + " ");
            }
            for (int j = 1; j <  i ; j++) {
                System.out.print((int)Math.pow(2, i-j-1) + " ");
            }

            System.out.println();
        }

    }

}
```
