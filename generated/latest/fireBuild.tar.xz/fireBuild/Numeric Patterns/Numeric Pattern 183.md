---
title: Numeric Pattern 183
---

# Numeric Pattern 183

![Numeric Pattern 183](/assets/patterns/numeric/numericpattern183.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern183.cpp"
#include <iostream>

using namespace std;

int main()
{
    for (int i=5;i>=1;i--)
    {
        for (int j=1;j<=i;j++)
        {
           if (i%2==0)
           cout<<'*';
           else
           cout<<i;
        }
        cout<<endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern183.java"


public class numericpattern183 {
    public static void main(String[] args) {
        int n=5;
        for (int row = 1; row <= n; row++) {
            if (row%2 == 0){
                for (int col = 1; col <= n-row +1 ; col++) {
                    System.out.print("* ");
                }
            }else{
                for (int col = 1; col <= n-row +1 ; col++) {
                    System.out.print(n -row +1 + " ");
                }
            }
            System.out.println();
        }
    }
}
```
