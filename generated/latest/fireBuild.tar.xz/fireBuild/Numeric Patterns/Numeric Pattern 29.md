---
title: Numeric Pattern 29
---

# Numeric Pattern 29

![Numeric Pattern 29](/assets/patterns/numeric/numericpattern29.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern29.cpp"
#include <iostream>

using namespace std;

int main()
{
    int c = 5;
    for (int i = 1; i <= 5; i++)
    {
        for (int j = c; j <= 5; j++)
        {
            cout << j;
        }
        c--;
        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
