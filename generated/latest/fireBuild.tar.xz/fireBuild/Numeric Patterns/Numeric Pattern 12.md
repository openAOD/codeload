---
title: Numeric Pattern 12
---

# Numeric Pattern 12

![Numeric Pattern 12](/assets/patterns/numeric/numericpattern12.PNG)
## C
```c title="./Assets/patterns/numeric/numericpattern12.c"
#include <stdio.h>

int main()
{
    int n,k=1,l;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        k=i;
        l=2*n-i+1;
        for(int j=1;j<=n;j++)
        {
            if(j%2!=0)
            {
            printf("%d ",k);
            k=k+2*n;
            }
            else
            {
            printf("%d ",l);
            l=l+2*n;
            }
        }
        printf("\n");
    }
    return 0;
}
```
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/numeric/numericpattern12.py"
# Numeric Pattern 12

"""
Desired Output:

1 10 11 20 21
2 9  12 19 22
3 8  13 18 23
4 7  14 17 24
5 6  15 16 25

"""

x = 9
y = 1
for i in range(1, 6):
    print(i, end=" ")
    for _ in range(2):
        i += x
        print(i, end=" ")
        i += y
        print(i, end=" ")

    x -= 2
    y += 2
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
