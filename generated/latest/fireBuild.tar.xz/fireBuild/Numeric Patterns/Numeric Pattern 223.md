---
title: Numeric Pattern 223
---

# Numeric Pattern 223

![Numeric Pattern 223](/assets/patterns/numeric/numericpattern223.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern223.java"

//pattern to be printed out
//5 * * * * *
//4 * * * *
//3 * * *
//2 * *
//1 *
//0

public class numericpattern223 {
    public static void main(String[] args) {
        int n = 6;
        for (int row = 1; row <= n ; row++) {
            for (int col = 1; col <= n-row+1; col++) {
                if (col == 1){
                    System.out.print(n-row + " ");
                }else{
                    System.out.print("* ");
                }
            }
            System.out.println();
        }
    }
}
```
