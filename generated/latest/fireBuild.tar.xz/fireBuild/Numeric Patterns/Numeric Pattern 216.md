---
title: Numeric Pattern 216
---

# Numeric Pattern 216

![Numeric Pattern 216](/assets/patterns/numeric/numericpattern216.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern216.java"

//pattern to be printed
//    1
//   A B
//  1 2 3
// A B C D
//1 2 3 4 5

public class numericpattern216 {
    public static void main(String[] args) {
        int n = 5;
        for (int row = 1; row <= n; row++) {
            for (int spaces = 1; spaces <= n-row; spaces++) {
                System.out.print(" ");
            }
            char value = row % 2 == 1?'1':'A';
            for (int col = 1; col <= 2*row - 1; col++) {
                if (col%2==0){
                    System.out.print(" ");
                }else{
                    System.out.print(value);
                    value++;
                }
            }
            System.out.println();
        }
    }
}
```
