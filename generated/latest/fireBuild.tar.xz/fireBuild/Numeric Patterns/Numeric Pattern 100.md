---
title: Numeric Pattern 100
---

# Numeric Pattern 100

![Numeric Pattern 100](/assets/patterns/numeric/numericpattern100.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern100.java"
/**
 * Pattern100
 *     1
      321
     54321
    7654321
   987654321
 * 
 */
class numericpattern100 {
    public static void main(String[] args) {
        int rows = 5;
        
        for (int i = 1; i <= rows; i++) {
            for (int j = rows; j > i; j--) {
                System.out.print(" ");
            }
            for (int k = 2*i-1; k >= 1; k--) {
                System.out.print(k);
                
            }
            System.out.println();
        
        }
    }
}
```
