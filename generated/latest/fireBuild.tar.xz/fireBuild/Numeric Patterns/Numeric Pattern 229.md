---
title: Numeric Pattern 229
---

# Numeric Pattern 229

![Numeric Pattern 229](/assets/patterns/numeric/numericpattern229.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern229.java"

//pattern to be printed
//5       1
//  4   2
//    3
//  4   2
//5       1

public class numericpattern229 {
    public static void main(String[] args) {
        int n= 5;
        for (int row = 1; row <= n; row++) {
            for (int col = 1; col <= n; col++) {
                if (col == row || n-col+1 == row){
                    System.out.print( n-col+1 + " ");
                }else{
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }
}
```
