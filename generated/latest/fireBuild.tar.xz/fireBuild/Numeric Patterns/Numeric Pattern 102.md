---
title: Numeric Pattern 102
---

# Numeric Pattern 102

![Numeric Pattern 102](/assets/patterns/numeric/numericpattern102.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern102.cpp"
#include <iostream>
using namespace std;

int main(){

    int n=5;

    for(int i=0; i<n; i++){
        for(int j=0; j<=n+i; j++){
            if(j<n-i){
                cout<<"  ";
            }
            else{
                cout<<j<<" ";
            }
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern102.java"
/**
 * Pattern102
 *      5
       456
      34567
     2345678
    123456789
 * 
 */
class numericpattern102 {
    public static void main(String[] args) {
        int rows = 5;
        
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j <= rows+i; j++) {
                if (j < rows-i) {
                    System.out.print(" ");
                } else {
                    System.out.print(j);
                }
            }
            System.out.println(); 
                
        }
    }
}
```
