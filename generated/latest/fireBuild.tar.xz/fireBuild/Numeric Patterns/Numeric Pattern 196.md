---
title: Numeric Pattern 196
---

# Numeric Pattern 196

![Numeric Pattern 196](/assets/patterns/numeric/numericpattern196.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern196.java"

//Pattern to be printed
// 5 5 5 5 5
//  * * * *
//   3 3 3
//    * *
//     1

public class numericpattern196 {
    public static void main(String[] args) {
        int n = 5;
        for (int row = 1; row <= n; row++) {
            for (int spaces = 1; spaces < row ; spaces++) {
                System.out.print(" ");
            }
            for (int col = 2*(n - row) + 1; col > 0 ; col--) {
                if (col % 2 == 1){
                    if (row % 2 == 1){
                        System.out.print(n-row+1 );
                    }else{
                        System.out.print("*");
                    }
                }else{
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
```
