---
title: Numeric Pattern 225
---

# Numeric Pattern 225

![Numeric Pattern 225](/assets/patterns/numeric/numericpattern225.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern225.java"

//pattern to be printed out
//* * * * * 5
//* * * * 4
//* * * 3
//* * 2
//* 1
//0

public class numericpattern225 {
    public static void main(String[] args) {
        int n = 6;
        for (int row = 1; row <= n ; row++) {
            for (int col = 1; col <= n-row+1; col++) {
                if (col == n-row+1){
                    System.out.print(n-row + " ");
                }else{
                    System.out.print("* ");
                }
            }
            System.out.println();
        }
    }
}

```
