---
title: Numeric Pattern 59
---

# Numeric Pattern 59

![Numeric Pattern 59](/assets/patterns/numeric/numericpattern59.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern59.cpp"

#include <iostream>

using namespace std;

int main()
{
    int s = 5, e = 1;
    for (int i = 1; i <= 5; i++)
    {
        for (int j = s; j >= e; j--)
        {
            cout << j;
        }
        cout << endl;
        s++;
        e = e + 2;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
