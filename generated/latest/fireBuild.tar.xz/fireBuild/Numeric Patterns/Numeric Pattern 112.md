---
title: Numeric Pattern 112
---

# Numeric Pattern 112

![Numeric Pattern 112](/assets/patterns/numeric/numericpattern112.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern112.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=3;

    int k=1;
    for(int i=1; i<=n; i++){
        for(int j=0; j<n-i; j++){
            cout<<"  ";
        }
        for(int j=0; j<(2*i)-1; j++){
            cout<<k*k<<" ";
            k++;
        }

        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern112.java"
/**
 * 
 * pattern to be printed 
 * 
 *       1
 *     4 9 16 
 * 25 36 49 64 81
 * numericpattern112
 */
public class numericpattern112 {

    public static void main(String[] args) {
        int rows = 3;
        numericPattern112(rows);
    }
    private static void numericPattern112(int n) {
        int c=1;
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= n - i; j++) {
                System.out.print("  ");
            }
        
            for (int j = 1; j <= 2* i -1; j++) {
                System.out.print((int)(Math.pow(c, 2)) + " ");
                c+=1;
            }
            System.out.println();
        }

    }

}
```
