---
title: Numeric Pattern 242
---

# Numeric Pattern 242

![Numeric Pattern 242](/assets/patterns/numeric/numericpattern242.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern242.java"

//pattern to be printed
//1
//1 2
//1   3
//1     4
//1 2 3 4 5

public class numericpattern242 {
    public static void main(String[] args) {
        int n = 5;
        for (int row = 1; row <= n; row++) {
            for (int col = 1; col <= row; col++) {
                if (row==n){
                    System.out.print(col + " ");
                }else if(col == 1 || col == row){
                    System.out.print(col + " ");
                }else{
                    System.out.print( "  ");
                }
            }
            System.out.println();
        }
    }
}
```
