---
title: Numeric Pattern 16
---

# Numeric Pattern 16

![Numeric Pattern 16](/assets/patterns/numeric/numericpattern16.PNG)
## C
```c title="./Assets/patterns/numeric/numericpattern16.c"
#include <stdio.h>

int main()
{
    int n,k=1,l=1;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        k=l;
        for(int j=1;j<=n;j++)
        {
            printf("%d ",k);
            k=k+2;
        }
        printf("\n");
        l=l+2;
    }
    return 0;
}
```
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/numeric/numericpattern16.py"
# Numeric Pattern 16

"""
Desired Pattern:

1  3  5  7  9
3  5  7  9 11
5  7  9 11 13
7  9 11 13 15
9 11 13 15 17

"""

for i in range(1, 10, 2):
    print(i, end=" ")
    for _ in range(4):
        print(i + 2, end = " ")
        i += 2
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
