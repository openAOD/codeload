---
title: Numeric Pattern 115
---

# Numeric Pattern 115

![Numeric Pattern 115](/assets/patterns/numeric/numericpattern115.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern115.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=5;

    for(int i=0; i<n; i++){
        for(int j=0; j<i; j++){
            cout<<"  ";
        }
        for(int j=1; j<=(2*(n-i))-1; j++){
            cout<<j<<" ";
        }

        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern115.java"
/**
 * 
 * pattern to be printed 
 * 
 *  1 2 3 4 5 6 7 8 9
 *    1 2 3 4 5 6 7
 *      1 2 3 4 5
 *        1 2 3
 *          1
 * numericpattern115
 */
public class numericpattern115 {
    public static void main(String[] args) {
        int rows = 5;
        numericPattern115(rows);
    }
    private static void numericPattern115(int n) {
        n+=1;
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <=  i; j++) {
                System.out.print("  ");
            }
        
            for (int j = 1; j <= 2* (n-i) -1; j++) {
                System.out.print(j + " ");
                
            }
            System.out.println();
        }

    }

}
    
```
