---
title: Numeric Pattern 67
---

# Numeric Pattern 67

![Numeric Pattern 67](/assets/patterns/numeric/numericpattern67.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern67.cpp"
#include <iostream>

using namespace std;

int main()
{
    bool flag;
    for (int i = 5; i >= 1; i--)
    {
        flag = true;
        for (int j = 1; j <= i; j++)
        {
            if (flag == true)
                cout << '1';
            else
                cout << '0';
            flag = !flag;
        }
        cout << endl;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
