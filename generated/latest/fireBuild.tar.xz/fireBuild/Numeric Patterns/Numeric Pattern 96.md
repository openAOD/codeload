---
title: Numeric Pattern 96
---

# Numeric Pattern 96

![Numeric Pattern 96](/assets/patterns/numeric/numericpattern96.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern96.cpp"
#include <iostream>

using namespace std;

int main()
{
    for (int i = 5; i >= 1; i--)
    {
        for (int j = 1; j <= (5 - i); j++)
        {
            cout << " ";
        }
        for (int k = i; k >= 1; k--)
        {
            cout << k << " ";
        }
        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern96.java"
/**
 * Pattern96
 *    5 4 3 2 1 
       4 3 2 1 
        3 2 1 
         2 1 
          1 
 */
class numericpattern96 {
    public static void main(String[] args) {
        int rows = 5;
        int temp = rows;
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j < i; j++) {
                System.out.print(" ");
            }
            for (int k = temp; k>=1; k--) {
                System.out.print(k + " ");
            }
            System.out.println();
            temp--;
        }
    }
}
```
