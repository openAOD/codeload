---
title: Numeric Pattern 126
---

# Numeric Pattern 126

![Numeric Pattern 126](/assets/patterns/numeric/numericpattern126.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern126.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=5;

    for(int i=1; i<=n; i++){
        for(int j=i; j<=n; j++){
            cout<<j<<"  ";
        }
        for(int j=0; j<i-1; j++){
            cout<<n<<"  ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
