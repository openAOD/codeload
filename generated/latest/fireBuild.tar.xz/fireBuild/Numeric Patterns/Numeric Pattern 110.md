---
title: Numeric Pattern 110
---

# Numeric Pattern 110

![Numeric Pattern 110](/assets/patterns/numeric/numericpattern110.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern110.cpp"
#include <iostream>
using namespace std;

int main(){

    int n=5;

    int k=1;
    for(int i=1; i<=n; i++){
        for(int j=0; j<n-i; j++){
            cout<<"  ";
        }
        for(int j=i; j<(2*i)-1; j++){
            cout<<j<<" ";
        }
        for(int j=(2*i)-1; j>=i; j--){
            cout<<j<<" ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern110.java"
/**
 * 
 * pattern to be printed 
 * 
 *       1
 *     2 3 2
 *   3 4 5 4 3
 * 4 5 6 7 6 5 4 
 * 
 * numericpattern110
 * 
 */
public class numericpattern110 {

    public static void main(String[] args) {
        int rows = 4;
        numericPattern110(rows);
    }
    private static void numericPattern110(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= n - i; j++) {
                System.out.print("  ");
            }
            int c=0;
            for (int j = 1; j <=  i ; j++) {
                System.out.print((i+j-1) + " ");
                c =i+j-1;
            }
            for (int j = 1; j <  i ; j++) {
                System.out.print((c-j) + " ");
            }

            System.out.println();
        }

    }

}
```
