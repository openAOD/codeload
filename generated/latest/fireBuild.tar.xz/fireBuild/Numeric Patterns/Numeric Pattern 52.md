---
title: Numeric Pattern 52
---

# Numeric Pattern 52

![Numeric Pattern 52](/assets/patterns/numeric/numericpattern52.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern52.cpp"
#include <iostream>

using namespace std;

int main()
{   
    
    for (int i = 1; i <= 6; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            if (j % 2 == 0)
                cout << '1';
            else
                cout << '0';
        }
        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern52.java"
/**
 * Pattern52
    0 
    0 1 
    0 1 0 
    0 1 0 1 
    0 1 0 1 0 
    0 1 0 1 0 1 
 */
class numericpattern52 {
    public static void main(String[] args) {
        int rows = 6;
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i; j++) {
                if (j%2 == 0) {
                    System.out.print("1 ");
                } else {
                    System.out.print("0 ");
                }
            }
            System.out.println();
        }
    }
}
```
