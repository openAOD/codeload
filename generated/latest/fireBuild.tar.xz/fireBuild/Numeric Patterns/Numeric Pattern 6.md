---
title: Numeric Pattern 6
---

# Numeric Pattern 6

![Numeric Pattern 6](/assets/patterns/numeric/numericpattern6.PNG)
## C
```c title="./Assets/patterns/numeric/numericpattern6.c"
#include <stdio.h>

int main()
{
    int n,k=1;
    scanf("%d",&n);
    for(int i=n;i>=1;i--)
    {
        for(int j=n;j>=1;j--)
        {
            if(k>9)
            printf("%d ",k);
            else
            printf(" %d ",k);
            k=k+2;
        }
        printf("\n");
    }
    return 0;
}
```
## C++
```cpp title="./Assets/patterns/numeric/numericpattern6.cpp"
#include <iostream>
using namespace std;

int main()
{
    int n = 5;
    int a = 1;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << a << " ";
            a += 2;
        }
        cout << endl;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/numeric/numericpattern6.py"
# Numeric Pattern 6

"""

1 3 5 7 9
11 13 15 17 19
21 23 25 27 29
31 33 35 37 39
41 43 45 47 49

"""

i = 0
nums = list(range(1, 50, 2))
for _ in range(5):
    j = i + 5
    row = " ".join(map(str, nums[i:j]))
    print(row)
    i = j
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
