---
title: Numeric Pattern 206
---

# Numeric Pattern 206

![Numeric Pattern 206](/assets/patterns/numeric/numericpattern206.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern206.java"

// pattern to be printed
//        A
//      1 2
//    A B C
//  1 2 3 4
//A B C D E

public class numericpattern206 {
    public static void main(String[] args) {
        int n = 5;
        for (int row = 1; row <= n ; row++) {
            for (int spaces = 1; spaces <= n-row; spaces++) {
                System.out.print("  ");
            }
            char value = row % 2 == 0 ? '1' : 'A';
            for (int col = 1; col <= row; col++) {
                System.out.print(value + " ");
                value++;
            }
            System.out.println();
        }
    }
}
```
