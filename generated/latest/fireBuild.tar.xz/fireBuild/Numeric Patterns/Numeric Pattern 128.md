---
title: Numeric Pattern 128
---

# Numeric Pattern 128

![Numeric Pattern 128](/assets/patterns/numeric/numericpattern128.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern128.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=5;

    for(int i=1; i<=n; i++){
        for(int j=i; j<=n; j++){
            cout<<j<<"  ";
        }
        for(int j=i-1; j>=1; j--){
            cout<<j<<"  ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
