---
title: Numeric Pattern 116
---

# Numeric Pattern 116

![Numeric Pattern 116](/assets/patterns/numeric/numericpattern116.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern116.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=5;

    for(int i=0; i<n; i++){
        for(int j=n; j>=n-i; j--){
            cout<<j<<" ";
        }
        cout<<endl;
    }
    for(int i=n; i>=0; i--){
        for(int j=n; j>=n-i; j--){
            cout<<j<<" ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern116.java"
/**
 * 
 * pattern to be printed 
 * 
 * 3
 * 3 2
 * 3 2 1
 * 3 2 1 0
 * 3 2
 * 3
 * numericpattern116
 */
public class numericpattern116 {
    public static void main(String[] args) {
        int rows = 6;
        numericPattern116(rows);
    }
    private static void numericPattern116(int n) {
        n/=2;
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <=  i; j++) {
                System.out.print((n-j)+"  ");
            }
            System.out.println();
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n-i; j++) {
                System.out.print((n-j)+"  ");
            }
            System.out.println();
        }

    }

}
    
```
