---
title: Numeric Pattern 121
---

# Numeric Pattern 121

![Numeric Pattern 121](/assets/patterns/numeric/numericpattern121.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern121.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=3;

    for(int i=0; i<n; i++){
        for(int j=0; j<=n-i-1; j++){
            cout<<"  ";
        }
        for(int j=n; j>=n-i; j--){
            cout<<j<<" ";
        }
        cout<<endl;
    }
    for(int i=n; i>=0; i--){
        for(int j=0; j<=n-i-1; j++){
            cout<<"  ";
        }
        for(int j=n; j>=n-i; j--){
            cout<<j<<" ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern121.java"
/**
 * 
 * pattern to be printed 
 * 
 *          3
 *        3 2
 *      3 2 1
 *    3 2 1 0
 *      3 2 1
 *        3 2
 *          3
 * 
 * 
 * numericpattern121
 */
public class numericpattern121 {


    public static void main(String[] args) {
        int rows = 7;
        numericPattern121(rows);
    }
    private static void numericPattern121(int n) {
    
        n/=2;
        for (int i = 0; i <= n; i++) {
            for (int j = 1; j <=n-i; j++) {
                System.out.print("  ");
            }
            for (int j = 0; j <=  i; j++) {
                System.out.print((n-j)+" ");
            }
            System.out.println();
        }
        for (int i = 0; i <= n; i++) {
            for (int j = -1; j <i; j++) {
                System.out.print("  ");
            }
            for (int j = 0; j < n-i; j++) {
                System.out.print((n-j)+" ");
            }
            System.out.println();
        }

    }

}    

```
