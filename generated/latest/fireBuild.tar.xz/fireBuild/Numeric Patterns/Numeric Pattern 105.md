---
title: Numeric Pattern 105
---

# Numeric Pattern 105

![Numeric Pattern 105](/assets/patterns/numeric/numericpattern105.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern105.cpp"
#include <iostream>
using namespace std;

int main(){

    int n=5;

    int k=1;
    for(int i=0; i<n; i++){
        for(int j=0; j<n-i-1; j++){
            cout<<"  ";
        }
        for(int j=i; j>0; j--){
            cout<<j<<" ";
        }
        for(int j=0; j<=i; j++){
            cout<<j<<" ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern105.java"
/**
 * 
 * pattern to be printed 
 * 
 *         0
 *       1 0 1
 *     2 1 0 1 2
 *   3 2 1 0 1 2 3
 * 4 3 2 1 0 1 2 3 4
 * 
 * 
 * numericpattern105
 */
public class numericpattern105 {
    public static void main(String[] args) {

        int rows = 5;
        numericPattern105(rows);
    }

    private static void numericPattern105(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= n - i; j++) {
                System.out.print("  ");
            }
            for (int j = 1; j <=  i ; j++) {
                System.out.print((i-j) + " ");
            }
            for (int j = 1; j <  i ; j++) {
                System.out.print((j) + " ");
            }

            System.out.println();
        }

    }

}
```
