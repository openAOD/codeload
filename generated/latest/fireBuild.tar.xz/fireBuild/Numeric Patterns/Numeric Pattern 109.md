---
title: Numeric Pattern 109
---

# Numeric Pattern 109

![Numeric Pattern 109](/assets/patterns/numeric/numericpattern109.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern109.cpp"
#include <iostream>
using namespace std;

int main(){

    int n=5;

    int k=1;
    for(int i=0; i<n; i++){
        for(int j=0; j<n-i; j++){
            cout<<"  ";
        }
        for(int j=n-i; j<n; j++){
            cout<<j<<" ";
        }
        for(int j=n; j>=n-i; j--){
            cout<<j<<" ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern109.java"
/**
 * 
 * pattern to be printed 
 * 
 *         5
 *       4 5 4
 *     3 4 5 4 3
 *   2 3 4 5 4 3 2
 * 1 2 3 4 5 4 3 2 1
 * 
 * 
 * numericpattern109
 */

public class numericpattern109 {
    public static void main(String[] args) {

        int rows = 5;
        numericPattern109(rows);
    }
    private static void numericPattern109(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= n - i; j++) {
                System.out.print("  ");
            }
            for (int j = 1; j <=  i ; j++) {
                System.out.print((i-j+1) + " ");
            }
            for (int j = 1; j <  i ; j++) {
                System.out.print((j+1) + " ");
            }

            System.out.println();
        }

    }

}
```
