---
title: Numeric Pattern 30
---

# Numeric Pattern 30

![Numeric Pattern 30](/assets/patterns/numeric/numericpattern30.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern30.cpp"
#include <iostream>
using namespace std;

int main()
{
    int n = 5;
    for (int i = 2; i <= 2*n; i+=2)
    {
        for (int j = 2; j <= i; j+=2)
        {
            cout << j << " ";
        }
        cout << endl;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/numeric/numericpattern30.py"
print("Enter the no of rows: ")
n = int(input())
for i in range(1, n+1):
    k = 2
    for j in range(1, i+1):
        print(k, end=" ")
        k = k + 2
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
