---
title: Numeric Pattern 19
---

# Numeric Pattern 19

![Numeric Pattern 19](/assets/patterns/numeric/numericpattern19.PNG)
## C
```c title="./Assets/patterns/numeric/numericpattern19.c"
#include <stdio.h>

int main()
{
    int n,k=1,l=1;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        k=l;
        for(int j=1;j<=n;j++)
        {
            if(i%2==0 || j%2==0)
            {
                printf("0 ");
            }
            else
            {
                printf("1 ");
            }
        }
        printf("\n");
    }
    return 0;
}
```
## C++
```cpp title="./Assets/patterns/numeric/numericpattern19.cpp"
#include <iostream>

using namespace std;

int main()
{
    bool flag;
    for (int i = 1; i <= 5; i++)
    {
        if (i % 2 == 0)
        {
            for (int j = 1; j <= 5; j++)
                cout << '0';
        }
        else
        {
            flag = true;
            for (int j = 1; j <= 5; j++)
            {
                if (flag == true)
                    cout << '1';
                else
                    cout << '0';
                flag = !flag;
            }
        }
        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
