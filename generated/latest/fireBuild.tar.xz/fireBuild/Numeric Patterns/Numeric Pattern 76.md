---
title: Numeric Pattern 76
---

# Numeric Pattern 76

![Numeric Pattern 76](/assets/patterns/numeric/numericpattern76.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern76.cpp"

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    int c = 2;
    for (int i = 1; i <= 5; i++)
    {
        for (int j = 1; j <= (5 - i); j++)
        {
            cout << "    ";
        }

        for (int k = 1; k <= i; k++)
        {
            cout << setw(4) << c;
            c += 2;
        }
        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
