---
title: Numeric Pattern 238
---

# Numeric Pattern 238

![Numeric Pattern 238](/assets/patterns/numeric/numericpattern238.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern238.java"
//pattern to be printed out
// 1 1 1 1 1
// 1       1
// 1       1
// 1       1
// 1 1 1 1 1

public class numericpattern238 {
    public static void main(String[] args) {
        int n = 5;
        for (int row = 1; row <= n; row++) {
            for (int col = 1; col <= n; col++) {
                if (col == 1 || col == n ||row == 1 || row==n){
                    System.out.print(1 +" ");
                }else{
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }
}
```
