---
title: Numeric Pattern 17
---

# Numeric Pattern 17

![Numeric Pattern 17](/assets/patterns/numeric/numericpattern17.PNG)
## C
```c title="./Assets/patterns/numeric/numericpattern17.c"
#include <stdio.h>

int main()
{
    int n,k=1,l=1;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        k=l;
        for(int j=1;j<=n;j++)
        {
            if(i%2==0)
            {
            if(i%2==0 && j%2==0)
            {
                printf("0 ");
            }
            else
            {
                printf("1 ");
            }
            }
            else
            {
                if(i%2==0 || j%2==0)
            {
                printf("1 ");
            }
            else
            {
                printf("0 ");
            }
            }
        }
        printf("\n");
    }
    return 0;
}
```
## C++
```cpp title="./Assets/patterns/numeric/numericpattern17.cpp"
#include <iostream>

using namespace std;

int main()
{   
    bool flag=true;
    for (int i=1;i<=5;i++)
    {
        for (int j=1;j<=5;j++)
        {
            if (flag==true)
            cout<<'0';
            else
            cout<<'1';
            flag=!flag;
        }
        cout<<endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/numeric/numericpattern17.py"
# Numeric Pattern 17

"""
Desired Pattern:

0 1 0 1 0
1 0 1 0 1
0 1 0 1 0
1 0 1 0 1
0 1 0 1 0

"""

# Creating a list of all nums
nums = ['0']

for i in range(12):
    nums += ['1', '0']

# Printing 5 nums per loop
i = 0
for _ in range(5):
    print(" ".join(nums[i : i + 5]))
    i += 5
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
