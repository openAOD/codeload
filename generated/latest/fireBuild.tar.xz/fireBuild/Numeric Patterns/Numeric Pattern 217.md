---
title: Numeric Pattern 217
---

# Numeric Pattern 217

![Numeric Pattern 217](/assets/patterns/numeric/numericpattern217.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern217.java"

//pattern to be printed
//E E E E E
// 4 4 4 4
//  C C C
//   2 2
//    1

public class numericpattern217 {
    public static void main(String[] args) {
        int n =5;
        char value = (char) (65 + (n-1));
        for (int row = 1; row <=5 ; row++) {
            for (int spaces = 1; spaces < row; spaces++) {
                System.out.print(" ");
            }
            for (int col = 1; col <= 2*(n-row)+1; col++) {
                if (col % 2 == 0){
                    System.out.print(" ");
                }else{
                    if (row % 2 == 0){
                        System.out.print( n-row+1);
                    }else{
                        System.out.print(value);
                    }
                }
            }
            value--;
            System.out.println();
        }
    }
}
```
