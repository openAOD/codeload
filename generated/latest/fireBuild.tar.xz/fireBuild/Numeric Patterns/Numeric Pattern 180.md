---
title: Numeric Pattern 180
---

# Numeric Pattern 180

![Numeric Pattern 180](/assets/patterns/numeric/numericpattern180.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern180.cpp"
#include <iostream>

using namespace std;

int main()
{
    for (int i=1;i<=5;i++)
    {
        for (int j=1;j<=i;j++)
        {
            if (i%2==0)
            cout<<'*';
            else
            cout<<j;
        }
        cout<<endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern180.java"


public class numericpattern180 {
    public static void main(String[] args) {
        int n=5;
        for (int row = 1; row <= n; row++) {
            if (row%2 == 0){
                for (int col = 1; col <= row ; col++) {
                    System.out.print("* ");
                }
            }else{
                for (int col = 1; col <= row ; col++) {
                    System.out.print(col + " ");
                }
            }
            System.out.println();
        }
    }
}
```
