---
title: Numeric Pattern 99
---

# Numeric Pattern 99

![Numeric Pattern 99](/assets/patterns/numeric/numericpattern99.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern99.java"
/**
 * Pattern99
 *     1
      123
     12345
    1234567
   123456789
 * 
 */
class numericpattern99 {
    public static void main(String[] args) {
        int rows = 5;
        for (int i = 1; i <= rows; i++) {
            for (int j= rows; j > i; j--) {
                System.out.print(" ");
            }
            for (int k = 1; k <= 2*i-1; k++) {
                System.out.print(k);
            }
            System.out.println();
        
        }
    }
}
```
