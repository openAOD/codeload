---
title: Numeric Pattern 188
---

# Numeric Pattern 188

![Numeric Pattern 188](/assets/patterns/numeric/numericpattern188.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern188.cpp"
#include <iostream>

using namespace std;

int main()
{
    for (int i=1;i<=5;i++)
    {   for (int k=1;k<=(5-i);k++)
        {
            cout<<" ";
        }
        for (int j=i;j>=1;j--)
        {
           if (i%2==0)
           cout<<'*';
           else
           cout<<j;
        }
        cout<<endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern188.java"


public class numericpattern188 {
    public static void main(String[] args) {
        int n= 5;
        for (int row = 1; row <= n; row++) {
            for (int spaces = n-row; spaces > 0 ; spaces--) {
                System.out.print("  ");
            }
            int col_num = row;
            for (int col = 1; col <= row; col++) {
                if (row % 2 == 1){
                    System.out.print(col_num-- +" ");
                }else{
                    System.out.print("* ");
                }
            }
            System.out.println();
        }
    }
}
```
