---
title: Numeric Pattern 36
---

# Numeric Pattern 36

![Numeric Pattern 36](/assets/patterns/numeric/numericpattern36.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern36.cpp"
#include <iostream>
using namespace std;

int main()
{
    int n = 5;
    int a = 2;
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= i; ++j)
        {
            cout << a << " ";
            a+=2;
        }
        cout << endl;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
