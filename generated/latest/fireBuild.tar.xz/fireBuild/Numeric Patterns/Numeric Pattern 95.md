---
title: Numeric Pattern 95
---

# Numeric Pattern 95

![Numeric Pattern 95](/assets/patterns/numeric/numericpattern95.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern95.cpp"

#include <iostream>

using namespace std;

int main()
{
    for (int i = 5; i >= 1; i--)
    {
        for (int j = 1; j <= (5 - i); j++)
        {
            cout << " ";
        }
        for (int k = 1; k <= i; k++)
        {
            cout << i << " ";
        }
        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern95.java"
/**
 * Pattern95
 *    5 5 5 5 5 
       4 4 4 4 
        3 3 3 
         2 2 
          1 
 */
class numericpattern95 {
    public static void main(String[] args) {
        int rows = 5;
        int temp = rows;
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j < i; j++) {
                System.out.print(" ");
            }
            for (int k = 1; k <= rows - i + 1; k++) {
                System.out.print(temp + " ");
            }
            System.out.println();
            temp--;
        }
    }
}
```
