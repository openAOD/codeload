---
title: Numeric Pattern 8
---

# Numeric Pattern 8

![Numeric Pattern 8](/assets/patterns/numeric/numericpattern8.PNG)
## C
```c title="./Assets/patterns/numeric/numericpattern8.c"
#include <stdio.h>

int main()
{
    int n,k;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        k=i;
        for(int j=n;j>=1;j--)
        {
            if(k>9)
            printf("%d ",k);
            else
            printf(" %d ",k);
            k=k+i;
        }
        printf("\n");
    }
    return 0;
}
```
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/numeric/numericpattern8.py"
# Numeric Pattern 8

"""

1 2 3 4 5
2 4 6 8 10
3 6 9 12 15
4 8 12 16 20
5 10 15 20 25

"""

def pattern(rows):
    for x in range(1, rows + 1):
        row = " ".join(map(str, [x * i for i in range(1, rows + 1)]))
        print(row)

pattern(5)
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
