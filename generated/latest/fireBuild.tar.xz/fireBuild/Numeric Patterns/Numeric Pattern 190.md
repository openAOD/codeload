---
title: Numeric Pattern 190
---

# Numeric Pattern 190

![Numeric Pattern 190](/assets/patterns/numeric/numericpattern190.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern190.cpp"
#include <iostream>

using namespace std;

int main()
{   int c=1;
    for (int i=5;i>=1;i--)
    {   for (int k=1;k<=(i-1);k++)
        {
            cout<<" ";
        }
        for (int j=c;j>=1;j--)
        {
           if (j%2==0)
           cout<<'*';
           else
           cout<<j;
        }
        c++;
        cout<<endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern190.java"


//Pattern to be printed
//        1
//      * 1
//    3 * 1
//  * 3 * 1
//5 * 3 * 1

public class numericpattern190 {
    public static void main(String[] args) {
        int n= 5;
        for (int row = 1; row <= n; row++) {
            int col_count = 1;
            for (int spaces = n-row; spaces > 0 ; spaces--) {
                System.out.print("  ");
                col_count++;
            }
            for (int col = 1; col <= row; col++) {
                if ( (n-col_count+1) % 2 == 1){
                    System.out.print( n-col_count+1 +" ");
                }else{
                    System.out.print("* ");
                }
                col_count++;
            }
            System.out.println();
        }
    }
}
```
