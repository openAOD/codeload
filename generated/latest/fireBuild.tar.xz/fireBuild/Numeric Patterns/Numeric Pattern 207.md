---
title: Numeric Pattern 207
---

# Numeric Pattern 207

![Numeric Pattern 207](/assets/patterns/numeric/numericpattern207.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern207.java"

// pattern to be printed
//        1
//      B B
//    3 3 3
//  D D D D
//5 5 5 5 5

public class numericpattern207 {
    public static void main(String[] args) {
        int n = 5;
        char value = 'A';
        for (int row = 1; row <= n ; row++) {
            for (int spaces = 1; spaces <= n-row; spaces++) {
                System.out.print("  ");
            }
            for (int col = 1; col <= row; col++) {
                if (row % 2 == 1){
                    System.out.print( row + " ");
                }else{
                    System.out.print(value + " ");
                }
            }
            value++;
            System.out.println();
        }
    }
}
```
