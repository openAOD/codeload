---
title: Numeric Pattern 11
---

# Numeric Pattern 11

![Numeric Pattern 11](/assets/patterns/numeric/numericpattern11.PNG)
## C
```c title="./Assets/patterns/numeric/numericpattern11.c"
#include <stdio.h>

int main()
{
    int n,k=1;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        k=i;
        for(int j=1;j<=n;j++)
        {
            printf("%d ",k);
            k=k+n;
        }
        printf("\n");
    }
    return 0;
}
```
## C++
```cpp title="./Assets/patterns/numeric/numericpattern11.cpp"
#include <iostream>
using namespace std;

int main()
{
    int n = 4;
    int a = 1;
    int x = 1;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            cout << a << " ";
            a += n;
        }
        x++;
        a = x;

        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/numeric/numericpattern11.py"
# Numeric Pattern 11

"""

1 6 11 16 21
2 7 12 17 22
3 8 13 18 23
4 9 14 19 24
5 10 15 20 25

"""

for i in range(1, 6):
    print(i, end=" ")
    for _ in range(4):
        x = i + 5
        print(x, end=" ")
        i = x
    print()

```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
