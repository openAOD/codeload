---
title: Numeric Pattern 119
---

# Numeric Pattern 119

![Numeric Pattern 119](/assets/patterns/numeric/numericpattern119.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern119.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=4;

    int k=1;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=i; j++){
            cout<<k++<<" ";
        }
        cout<<endl;
    }
    for(int i=1; i<n; i++){
        for(int j=1; j<=n-i; j++){
            cout<<k++<<" ";
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern119.java"
/**
 * 
 * pattern to be printed 
 * 
 *  1
 *  2 3
 *  4 5 6
 *  7 8 9 10
 * 11 12 13
 * 14 15
 * 16
 * 
 * numericpattern119
 */
public class numericpattern119 {
    public static void main(String[] args) {
        int rows = 6;
        numericPattern119(rows);
    }
    private static void numericPattern119(int n) {
        int c=1;
        n/=2;
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <=  i; j++) {
                System.out.print((c)+"  ");
                c++;
            }
            System.out.println();
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n-i; j++) {
                System.out.print((c)+"  ");
                c++;
            }
            System.out.println();
        }

    }

}


```
