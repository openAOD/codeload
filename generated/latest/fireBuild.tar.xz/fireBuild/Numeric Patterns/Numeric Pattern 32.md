---
title: Numeric Pattern 32
---

# Numeric Pattern 32

![Numeric Pattern 32](/assets/patterns/numeric/numericpattern32.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern32.cpp"
#include <iostream>

using namespace std;

int main()
{

    for (int i = 0; i <= 4; i++)
    {
        for (int j = 1; j <= (i + 1); j++)
        {
            cout << j + i;
        }

        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
