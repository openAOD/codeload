---
title: Numeric Pattern 2
---

# Numeric Pattern 2

![Numeric Pattern 2](/assets/patterns/numeric/numericpattern2.PNG)
## C
```c title="./Assets/patterns/numeric/numericpattern2.c"
#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            printf("%d ",j);
        }
        printf("\n");
    }
    return 0;
}
```
## C++
```cpp title="./Assets/patterns/numeric/numericpattern2.cpp"
#include <iostream>
using namespace std;

int main(){
    int n = 5;
    for (int i = 1; i <=n; i++)
    {
        for (int j = 1; j <=n;j++)
        {
              cout<<j<<" ";
        }
        cout<<endl;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/numeric/numericpattern2.py"
# Numeric Pattern 2

"""
Desired Output:
1 2 3 4 5
1 2 3 4 5
1 2 3 4 5
1 2 3 4 5
"""

pattern = " ".join(map(str, list(range(1, 6))))
for _ in range(5):
    print(pattern)
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
