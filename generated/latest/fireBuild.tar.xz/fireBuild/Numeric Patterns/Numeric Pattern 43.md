---
title: Numeric Pattern 43
---

# Numeric Pattern 43

![Numeric Pattern 43](/assets/patterns/numeric/numericpattern43.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern43.cpp"
#include <iostream>

using namespace std;

int main()
{
    int c = 1, n;
    for (int i = 1; i <= 5; i++)
    {

        n = c;
        while (n > 0)
        {
            cout << n % 10 << " ";
            n = n / 10;
        }
        cout << endl;
        c = c * 11;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
