---
title: Numeric Pattern 103
---

# Numeric Pattern 103

![Numeric Pattern 103](/assets/patterns/numeric/numericpattern103.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern103.cpp"
#include <iostream>
using namespace std;

int main(){

    int n=5;

    for(int i=0; i<n; i++){
        for(int j=2*n; j>=0; j--){
            if(j>=n-i && j<=n+i){
                cout<<j<<"  ";
            }
            else{
                cout<<"  ";
            }
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern103.java"
/**
 * 
 * pattern to be printed 
 * 
 *         5
 *       6 5 4
 *     7 6 5 4 3
 *   8 7 6 5 4 3 2
 * 9 8 7 6 5 4 3 2 1
 * 
 * numericpattern103
 */
public class numericpattern103 {

    public static void main(String[] args) {

        int rows = 5;
       numericPattern103(rows);
    }

    private static void numericPattern103(int n) {

        for (int i = n; i >= 1; i--) {
            for (int j = 0; j <= i; j++) {
                System.out.print("  ");
            }
            for (int j =i; j <=n ; j++) {
                System.out.print((2*n-j) + " ");
            }
            for (int j =i+1; j <=n ; j++) {
                System.out.print((n+i-j) + " ");
            }
            System.out.println();
        }

    }

   
}

```
