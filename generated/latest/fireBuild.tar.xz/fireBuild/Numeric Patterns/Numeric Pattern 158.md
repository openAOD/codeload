---
title: Numeric Pattern 158
---

# Numeric Pattern 158

![Numeric Pattern 158](/assets/patterns/numeric/numericpattern158.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern158.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=5;
    int arr[n][n];
    int x=n, y=n;
    while(y>0){
        for(int i=0; i<x; i++){
            for(int j=0; j<y; j++)
                arr[i][j]=y;
        }
        x--; y--;
    }

    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++)
            cout<<arr[i][j]<<" ";
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
