---
title: Numeric Pattern 186
---

# Numeric Pattern 186

![Numeric Pattern 186](/assets/patterns/numeric/numericpattern186.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern186.cpp"
#include <iostream>

using namespace std;

int main()
{
    for (int i=5;i>=1;i--)
    {
        for (int j=1;j<=i;j++)
        {
           if (j%2==0)
           cout<<'*';
           else
           cout<<i;
        }
        cout<<endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern186.java"


public class numericpattern186 {
    public static void main(String[] args) {
        int n=5;
        for (int row = 1; row <= n; row++) {
            for (int col = 1; col <=n- row+ 1; col++) {
                if (col % 2 == 0){
                    System.out.print("* ");
                }else{
                    System.out.print(n-row+1 + " ");
                }
            }
            System.out.println();
        }
    }
}
```
