---
title: Numeric Pattern 231
---

# Numeric Pattern 231

![Numeric Pattern 231](/assets/patterns/numeric/numericpattern231.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern231.java"

//pattern to be printed
//    5
//    4
//1 2 3 4 5
//    2
//    1

public class numericpattern231 {
    public static void main(String[] args) {
        int n= 5;
        for (int row = 1; row <= n; row++) {
            for (int col = 1; col <= n; col++) {
                int value = col == n/2+1 ? n-row+1 : col;
                if (col == n/2+1 || row == n/2+1){
                    System.out.print(value + " ");
                }else{
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }
}
```
