---
title: Numeric Pattern 241
---

# Numeric Pattern 241

![Numeric Pattern 241](/assets/patterns/numeric/numericpattern241.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern241.java"

//pattern to be printed
//1
//2 2
//3   3
//4     4
//5 5 5 5 5

public class numericpattern241 {
    public static void main(String[] args) {
        int n = 5;
        for (int row = 1; row <= n; row++) {
            for (int col = 1; col <= row; col++) {
                if (row==n){
                    System.out.print(n + " ");
                }else if(col == 1 || col == row){
                    System.out.print(row + " ");
                }else{
                    System.out.print( "  ");
                }
            }
            System.out.println();
        }
    }
}
```
