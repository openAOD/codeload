---
title: Numeric Pattern 159
---

# Numeric Pattern 159

![Numeric Pattern 159](/assets/patterns/numeric/numericpattern159.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern159.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=5;
    int arr[n][n];
    int x=1, y=n;
    while(y>0){
        for(int i=x-1; i<n; i++){
            for(int j=0; j<y; j++)
                arr[i][j]=y;
        }
        x++; y--;
    }

    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++)
            cout<<arr[i][j]<<" ";
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
