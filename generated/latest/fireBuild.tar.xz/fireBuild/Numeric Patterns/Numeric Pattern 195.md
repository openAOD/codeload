---
title: Numeric Pattern 195
---

# Numeric Pattern 195

![Numeric Pattern 195](/assets/patterns/numeric/numericpattern195.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern195.java"

//Pattern to be printed
//         1
//        * *
//       3 3 3
//      * * * *
//     5 5 5 5 5

public class numericpattern195 {
    public static void main(String[] args) {
        int n = 5;
        for (int row = 1; row <= n; row++) {
            for (int spaces = 1; spaces <= n-row ; spaces++) {
                System.out.print(" ");
            }
            for (int col = 1; col <= 2*row - 1; col++) {
                if (col % 2 == 1){
                    if (row % 2 == 1){
                        System.out.print(row );
                    }else{
                        System.out.print("*");
                    }
                }else{
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
```
