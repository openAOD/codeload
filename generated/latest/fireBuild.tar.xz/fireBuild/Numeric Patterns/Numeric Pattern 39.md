---
title: Numeric Pattern 39
---

# Numeric Pattern 39

![Numeric Pattern 39](/assets/patterns/numeric/numericpattern39.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern39.cpp"
#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int> arr[5];
    int c = 1;
    bool flag = true;
    for (int i = 5; i >= 1; i--)
    {
        if (flag == true)
        {
            for (int j = 0; j < i; j++)
            {
                arr[j + 5 - i].push_back(c);
                c++;
            }
        }
        else
        {
            for (int j = 4; j >= (5 - i); j--)
            {
                arr[j].push_back(c);
                c++;
            }
        }
        flag = !flag;
    }
    for (int i = 0; i < 5; i++)
    {
        for (int j = arr[i].size() - 1; j >= 0; j--)
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
