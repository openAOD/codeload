---
title: Numeric Pattern 104
---

# Numeric Pattern 104

![Numeric Pattern 104](/assets/patterns/numeric/numericpattern104.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern104.cpp"
#include <iostream>
using namespace std;

int main(){

    int n=5;

    int k=1;
    for(int i=0; i<n; i++){
        for(int j=2*n; j>=0; j--){
            if(j>=n-i && j<=n+i){
                cout<<k++<<"  ";
            }
            else{
                cout<<"  ";
            }
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/numeric/numericpattern104.java"
/**
 * 
 * pattern to be printed
 * 
 *           1
 *         2 3 4
 *        5 6 7 8 9
 *    10 11 12 13 14 15 16
 * 17 18 19 20 21 22 23 24 25
 * 
 * numericpattern104
 */
public class numericpattern104 {
    public static void main(String[] args) {

        int rows = 5;
        numericPattern104(rows);
    }

    private static void numericPattern104(int n) {
        int c = 1;
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= n - i; j++) {
                System.out.print("  ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {

                System.out.print((c) + " ");
                c++;
            }
            System.out.println();
        }

    }

}
```
