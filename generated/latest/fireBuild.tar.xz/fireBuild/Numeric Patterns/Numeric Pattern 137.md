---
title: Numeric Pattern 137
---

# Numeric Pattern 137

![Numeric Pattern 137](/assets/patterns/numeric/numericpattern137.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern137.cpp"
#include <iostream>
#include <math.h>
using namespace std;

int main(){

    int n=4;

    int k=1;
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            cout<<k++<<" ";
            if(k%8==0)
                k+=2;
        }
        cout<<endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
