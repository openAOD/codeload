---
title: Numeric Pattern 74
---

# Numeric Pattern 74

![Numeric Pattern 74](/assets/patterns/numeric/numericpattern74.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/numeric/numericpattern74.cpp"
#include <iostream>

using namespace std;

int main()
{
    int c = 5;
    for (int i = 5; i >= 1; i--)
    {
        for (int j = 1; j <= (i - 1); j++)
        {
            cout << " ";
        }
        for (int k = c; k <= 5; k++)
        {
            cout << k;
        }
        cout << endl;
        c--;
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
