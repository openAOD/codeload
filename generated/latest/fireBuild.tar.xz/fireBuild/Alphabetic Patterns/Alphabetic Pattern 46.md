---
title: Alphabetic Pattern 46
---

# Alphabetic Pattern 46

![Alphabetic Pattern 46](/assets/patterns/alphabetic/alphabeticpattern46.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern46.cpp"
#include<bits/stdc++.h>
using namespace std;

int main()
{
    int start=4; //since start is A+3
    for (int i=1;i<=start;i++)
    {
        int k=start;                    //since start value is D(A+3)
        for (int j=i;j>=1;j--)      //for reaching maxima 
        {
            char a= 65+k+(j-i)-1;    
            cout << a << " ";
        }
        cout << "\n";
    }
     for (int i=start-1;i>=1;i--)
    {
        int k=start;
        for (int j=i;j>=1;j--)      //for reaching minima
        {
            char a= 65+k+(j-i)-1;
            cout << a << " ";
        }
        cout << "\n";
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern46.java"
/**
 * 
 * pattern to be printed
 * 
 * D
 * D C
 * D C B
 * D C B A
 * D C B
 * D C
 * D
 * alphabeticpattern46
 */
public class alphabeticpattern46 {

    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern46(rows);
    }

    private static void alphabetPattern46(int n) {

        int alphabet = 64;
        for (int i = n; i >= 1; i--) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print((char) (alphabet + n - j) + " ");
            }
            System.out.println();
        }
        for (int i = n - 2; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print((char) (alphabet + n - j) + " ");
            }
            System.out.println();
        }

    }
}
```
