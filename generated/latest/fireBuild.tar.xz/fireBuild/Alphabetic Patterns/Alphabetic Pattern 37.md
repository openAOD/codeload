---
title: Alphabetic Pattern 37
---

# Alphabetic Pattern 37

![Alphabetic Pattern 37](/assets/patterns/alphabetic/alphabeticpattern37.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern37.cpp"
#include<bits/stdc++.h>
//#include<iostream>
using namespace std;
int main(){
    for(int i=0;i<5;i++){   
        int k=4-i;
        while (k--)         //for spaces before first character
        {
            cout<<"  ";
        }
        
        for (int j = 0; j < 2*i+1; j++)
        {
            char a=65+2*i;
            cout<<a<<" ";
        }
        cout<<endl;
    }
 return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern37.java"
//pattern to be printed
//    A
//   CCC
//  EEEEE
// IIIIIII


/**
 * alphabeticpattern37
 */
public class alphabeticpattern37 {
    public static void main(String[] args) {

        int rows = 6;
        alphabetPattern37(rows);
    }

    private static void alphabetPattern37(int n) {

        int alphabet = 64;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < 2*i-1; j++) {
                
                 System.out.print((char) (alphabet + 2*i-1));
            }
            System.out.println();
        }
    
    }
}
```
