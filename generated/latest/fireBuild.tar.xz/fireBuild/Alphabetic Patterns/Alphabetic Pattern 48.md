---
title: Alphabetic Pattern 48
---

# Alphabetic Pattern 48

![Alphabetic Pattern 48](/assets/patterns/alphabetic/alphabeticpattern48.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern48.cpp"
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int start=4; //since start is A+4
    for (int i=1;i<=start;i++)
    {
        int k=i;                     //start value from A   
        for (int j=1;j<=i;j++)      //for reaching maxima 
        {
            char a= 65+k+(j-i)-1;    
            cout << a << " ";
        }
        cout << "\n";
    }
     for (int i=start-1;i>=1;i--)
    {
        int k=i;
        for (int j=1;j<=i;j++)      //for reaching minima
        {
            char a= 65+k+(j-i)-1;
            cout << a << " ";
        }
        cout << "\n";
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern48.java"
/**
 * 
 * pattern to be printed 
 * 
 * A 
 * A B 
 * A B C 
 * A B C D
 * A B C
 * A B
 * A
 * 
 * alphabeticpattern48
 */
public class alphabeticpattern48 {

    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern48(rows);
    }

    private static void alphabetPattern48(int n) {

        int alphabet = 64;
        for (int i = n; i >= 1; i--) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print((char) (alphabet+j ) + " ");
            }
            System.out.println();
        }
        for (int i = n - 2; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print((char) (alphabet+j) + " ");
            }
            System.out.println();
        }

    }
}
```
