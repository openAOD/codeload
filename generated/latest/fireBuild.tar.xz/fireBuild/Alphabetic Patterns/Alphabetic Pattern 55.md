---
title: Alphabetic Pattern 55
---

# Alphabetic Pattern 55

![Alphabetic Pattern 55](/assets/patterns/alphabetic/alphabeticpattern55.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern55.cpp"

#include<bits/stdc++.h>
using namespace std;

int main()
{
    int curr_char=4; //same as 54 but current characater decreases
    for (int i=1;i<=5;i++)
    {
        for (int j=0;j<5;j++)
        {
            if (j%2!=0)                //for 2nd and 4th column values need to be in reverse order
            {char a = 65+(9*(j/2 +1)-curr_char+(j/2));     // j/2 decides which column it is 
            cout << a << " ";}
            else
            {
                char a=65+(curr_char+5*j);
                cout << a << " ";}
        }
        curr_char--;
        cout << "\n";
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern55.java"
/**
 * 
 * pattern to be printed
 * 
 * E F O P Y
 * D G N Q X
 * C H M R W
 * B I L S V
 * A J K T U
 * 
 * 
 * alphabeticpattern55
 */
public class alphabeticpattern55 {

    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern55(rows);
    }

    private static void alphabetPattern55(int n) {

        int alphabet = 64;
        for (int i = n; i >= 1; i--) {
            for (int j = 0; j < n; j++) {
                System.out.print((char) (alphabet + i + j) + " ");
            }
            System.out.println();
        }

    }
}
```
