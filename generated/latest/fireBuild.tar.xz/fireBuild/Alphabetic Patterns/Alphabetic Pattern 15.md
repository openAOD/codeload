---
title: Alphabetic Pattern 15
---

# Alphabetic Pattern 15

![Alphabetic Pattern 15](/assets/patterns/alphabetic/alphabeticpattern15.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern15.cpp"
#include <iostream>
using namespace std;

int main()
{
    char count='E';
    
    for(int i=0;i<5;i++)
    {
        for(char j='A';j<=count;j++)
        {
            cout<<j<<" ";
        }
        
        count--;
        
        cout<<"\n";
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern15.java"
// program to print following pattern
// A B C D E
// A B C D
// A B C
// A B
// A

public class alphabeticpattern15 {

    public static void main(String[] args) {

        int rows = 5;
        alphabet_triangle(rows);
    }
    static void alphabet_triangle(int n){

        int alphabet = 65;
        for (char i = 1 ; i <= n ; i++) {
            for (char j = 0 ; j < n-i+1 ; j++) {
                System.out.print((char)(alphabet + j) + " ");
            }
            System.out.println();
        }
    }
}
```
