---
title: Alphabetic Pattern 149
---

# Alphabetic Pattern 149

![Alphabetic Pattern 149](/assets/patterns/alphabetic/alphabeticpattern149.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern149.cpp"
#include <iostream>
using namespace std;

int main()
{
    int height = 5;
    int i, j;
    for (i = 0; i < height; i++)
    {
        for (j = 0; j < height; j++)
        {
            if(i == 0) cout<<"* ";
            else if (i == height - 1 && (j > 0 && j < height - 1))
                cout << "*";
            else if ((j == height - 1 && i != height - 1) || (i > (height / 2) - 1 && j == 0 && i != height - 1))
                cout << "*";
            else
                cout << " ";
        }
        cout << "\n";
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern149.py"
height = 5
for i in range(0, height):
    for j in range(0, height):
        if (i == height - 1 and (j > 0 and j < height - 1)):
            print("*", end="")
        elif ((j == height - 1 and i != height - 1) or (i > (height // 2) - 1 and j == 0 and i != height - 1)):
            print("*", end="")
        else:
            print(end=" ")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
