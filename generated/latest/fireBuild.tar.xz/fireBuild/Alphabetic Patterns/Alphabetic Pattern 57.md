---
title: Alphabetic Pattern 57
---

# Alphabetic Pattern 57

![Alphabetic Pattern 57](/assets/patterns/alphabetic/alphabeticpattern57.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern57.cpp"
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int cur_char=0;   //starts from A
    for (int i=1;i<=5;i++)
    {
        for (int j=0;j<i;j++) //to print number
        cout << 6-i << " ";
        for (int k=i;k<5;k++) //to print character
        {
            char a = 65+cur_char;
            cout << a << " ";
        }
        cur_char++;   //new character at every line.
        cout << "\n";
    }
} 
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern57.java"
/**
 * pattern to be printed
 * 
 *  5 A A A A 
 *  4 4 B B B
 *  3 3 3 C C
 *  2 2 2 2 D
 *  1 1 1 1 1
 * 
 * 
 * alphabeticpattern57
 */
public class alphabeticpattern57 {
    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern57(rows);
    }

    private static void alphabetPattern57(int n) {

        int alphabet = 64;
        for (int i = n; i >= 1; i--) {
            for (int j = 0; j <= n-i; j++) {
                System.out.print((i)+ " ");
            }
            for (int j = n-i+1; j < n; j++) {
                System.out.print((char) (alphabet +n-i+1) + " ");
            }
            System.out.println();
        }

    }
}

```
