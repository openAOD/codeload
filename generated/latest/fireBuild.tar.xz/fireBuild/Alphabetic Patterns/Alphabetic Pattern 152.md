---
title: Alphabetic Pattern 152
---

# Alphabetic Pattern 152

![Alphabetic Pattern 152](/assets/patterns/alphabetic/alphabeticpattern152.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern152.py"
height = 5
counter = 0
for i in range(0, height):
    print("*", end="")
    for j in range(0, height+1):
        if (j == height):
            print("*", end="")
        elif (j == counter or j == height - counter - 1):
            print("*", end="")
        else:
            print(end=" ")
    if(counter == height // 2):
        counter = -99999
    else:
        counter = counter + 1

    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
