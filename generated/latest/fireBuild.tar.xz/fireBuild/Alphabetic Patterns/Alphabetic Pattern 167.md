---
title: Alphabetic Pattern 167
---

# Alphabetic Pattern 167

![Alphabetic Pattern 167](/assets/patterns/alphabetic/alphabeticpattern167.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern167.cpp"
#include <iostream>
using namespace std;

int main()
{
     int height = 5;
    int width = (2 * height) - 1;
   int i, j, half = (height / 2);
    for (i = 0; i < height; i++) {
        cout <<"B";
        for (j = 0; j < width; j++) {
            if ((i == 0 || i == height - 1 || i == half)
                && j < (width - 2))
                cout <<"B";
            else if (j == (width - 2)
                    && !(i == 0 || i == height - 1
                        || i == half))
                cout <<"B";
            else
                cout <<" ";
        }
        cout <<"\n";
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern167.py"
height = 5
width = 2 * height - 1
half = height // 2

for i in range(0, height):
    print("*", end="")
    for j in range(0, width):
        if (i == 0 or i == height - 1 or i == half) and j < (width - 2):
            print("B", end="")
        elif j == (width - 2) and not (i == 0 or i == height - 1 or i == half):
            print("B", end="")
        else:
            print(end=" ")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
