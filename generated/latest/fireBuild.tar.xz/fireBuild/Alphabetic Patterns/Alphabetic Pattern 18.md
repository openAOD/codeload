---
title: Alphabetic Pattern 18
---

# Alphabetic Pattern 18

![Alphabetic Pattern 18](/assets/patterns/alphabetic/alphabeticpattern18.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern18.cpp"
#include <iostream>
using namespace std;

int main() {
    
    char strt='E';
    
    for(int i=0;i<5;i++)
    {
        
      for(char j=strt;j>='A';j--)
        {
            cout<<j<<" ";
        }
        
        strt--;
        cout<<"\n";
    }
      

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern18.py"
size = int(input("Enter Number of Rows:  "))
for i in range(0, size):
    for j in range(64+size-i, 64, -1):
        a = chr(j)
        print(a, end="")
    print()
```
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern18.java"
// program to print following pattern
// E D C B A
// D C B A
// C B A
// B A
// A

public class alphabeticpattern18 {

    public static void main(String[] args) {

        int rows = 5;
        alphabet_triangle(rows);
    }
    static void alphabet_triangle(int n){

        int alphabet = 64;
        for (char i = (char) n; i > 0 ; i--) {
            for (char j = i; j > 0 ; j--) {
                System.out.print((char)(alphabet + j) + " ");
            }
            System.out.println();
        }
    }
}
```
