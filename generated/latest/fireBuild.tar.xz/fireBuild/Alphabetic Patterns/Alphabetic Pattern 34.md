---
title: Alphabetic Pattern 34
---

# Alphabetic Pattern 34

![Alphabetic Pattern 34](/assets/patterns/alphabetic/alphabeticpattern34.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern34.cpp"
#include<bits/stdc++.h>
using namespace std;
int main(){
    for(int i=4;i>=0;i--){    //for 5 line of output i is 4
        int j=4-i;            //for number of spaces before first character
        while(j--){
            cout<<" ";
        }
        for (int k = i ; k>=0; k--)
        {
            char a=65+k;      // ascii value of A is 65
            cout<<a<<" ";
        }
        cout<<"\n";
    }
 return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern34.java"
//pattern to be printed
//E D C B A
// D C B A
//  C B A
//   B A
//    A



/**
 * alphabeticpattern34
 */
public class alphabeticpattern34 {

    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern34(rows);
    }

    private static void alphabetPattern34(int n) {

        int alphabet = 64;
        for (char i = (char) n; i > 0; i--) {
            for (int index = n; index >=i; index--) {
                System.out.print(" ");
            }
            for (char j = i; j > 0; j--) {    
                System.out.print((char) (alphabet + j) + " ");
            }
            System.out.println();
        }
    }

}

```
