---
title: Alphabetic Pattern 54
---

# Alphabetic Pattern 54

![Alphabetic Pattern 54](/assets/patterns/alphabetic/alphabeticpattern54.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern54.cpp"
#include<bits/stdc++.h>
using namespace std;

int main()
{
    int curr_char=0;
    for (int i=1;i<=5;i++)
    {
        for (int j=0;j<5;j++)
        {
            if (j%2!=0)                //for 2nd and 4th column values need to be in reverse order
            {char a = 65+(9*(j/2 +1)-curr_char+(j/2));     // j/2 decides which column it is 
            cout << a << " ";}
            else
            {
                char a=65+(curr_char+5*j);
                cout << a << " ";}
        }
        curr_char++;
        cout << "\n";
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern54.java"
// program to print hollow rectangle
// * * * * *
// *       *
// *       *
// *       *
// * * * * *

public class alphabeticpattern54 {

    public static void main(String[] args) {

        int rows = 5;
        int columns = 5;
        print_rectangle(rows,columns);
    }
    static void print_rectangle(int n, int m){
        int i, j;

        // For rows of rectangle, run the outer loop from 1 to rows.
        for (i = 1; i <= n; i++)
        {
            // For column of rectangle, run the inner loop from 1 to columns.
            for (j = 1; j <= m; j++)
            {
                // Print star for first or for last row or for first or last column
                if (i == 1 || i == n ||
                        j == 1 || j == m)
                    System.out.print("* ");
                else

                    // else print blank space.
                    System.out.print("  ");
            }

            // After printing all columns of a row, print new line after inner loop
            System.out.println();
        }
    }
}
```
