---
title: Alphabetic Pattern 180
---

# Alphabetic Pattern 180

![Alphabetic Pattern 180](/assets/patterns/alphabetic/alphabeticpattern180.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern180.py"
height = 5
space = height // 3
width = height // 2 + height // 5 + space + space
for i in range(0, height):
    for j in range(0, width + 1):
        if (j == width - abs(space) or j == abs(space)):
            print("O", end="")
        elif((i == 0 or i == height - 1) and j > abs(space) and j < width - abs(space)):
            print("O", end="")
        else:
            print(end=" ")

    if(space != 0 and i < height // 2):
        space = space - 1
    elif (i >= (height // 2 + height // 5)):
        space = space - 1

    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
