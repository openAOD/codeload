---
title: Alphabetic Pattern 10
---

# Alphabetic Pattern 10

![Alphabetic Pattern 10](/assets/patterns/alphabetic/alphabeticpattern10.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern10.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {
    
    for (int j=1;j<=5;j++)
    {
        for (int i=1;i<j+1;i++)
        {
            char x = (char) (i-1)+65;
            cout << x << " ";
        }
       cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern10.py"
row = int(input("Enter number of rows : "))
for i in range(1, row+1):
    for j in range(65, 65+i):
        print(chr(j), end=' ')
    print()
```
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern10.java"
// program to print following pattern
// A
// A B
// A B C
// A B C D
// A B C D E

public class alphabeticpattern10 {

    public static void main(String[] args) {

        int rows = 5;
        alphabet_rectangle(rows);
    }
    static void alphabet_rectangle(int n){

        int alphabet = 64;
        for (char i = 1 ; i <= n ; i++) {
            for (char j = 1 ; j <= i ; j++) {
                System.out.print((char)(alphabet + j) + " ");
            }
            System.out.println();
        }
    }
}
```
