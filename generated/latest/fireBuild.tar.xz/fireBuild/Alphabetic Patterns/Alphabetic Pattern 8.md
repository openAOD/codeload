---
title: Alphabetic Pattern 8
---

# Alphabetic Pattern 8

![Alphabetic Pattern 8](/assets/patterns/alphabetic/alphabeticpattern8.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern8.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {


    for (int j=4;j>=0;j--)
    {
       for (int i=0;i<5;i++)
       {
           int c= j+i*5;
           char x = (char) c+65;
           cout << x << " ";
       }
       cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
