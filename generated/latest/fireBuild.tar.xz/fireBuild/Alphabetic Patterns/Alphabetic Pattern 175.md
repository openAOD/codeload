---
title: Alphabetic Pattern 175
---

# Alphabetic Pattern 175

![Alphabetic Pattern 175](/assets/patterns/alphabetic/alphabeticpattern175.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern175.cpp"
#include <iostream>
using namespace std;

int main()
{
    int height = 5;
    int i, j;
    for (i = 0; i < height; i++)
    {
        for (j = 0; j < height; j++)
        {
            if(i == 0) cout<<"J ";
            else if (i == height - 1 && (j > 0 && j < height - 1))
                cout << "J";
            else if ((j == height - 1 && i != height - 1) || (i > (height / 2) - 1 && j == 0 && i != height - 1))
                cout << "J";
            else
                cout << " ";
        }
        cout << "\n";
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern175.py"
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
