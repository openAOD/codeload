---
title: Alphabetic Pattern 140
---

# Alphabetic Pattern 140

![Alphabetic Pattern 140](/assets/patterns/alphabetic/alphabeticpattern140.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern140.cpp"
#include <iostream>
using namespace std;

int main()
{
    int height = 5;
    int width = (2 * height) - 1;
    int n = width / 2, i, j;
    for (i = 0; i < height; i++)
    {
        for (j = 0; j <= width; j++)
        {
            if (j == n || j == (width - n) || (i == height / 2 && j > n && j < (width - n)))
                cout << "*";
            else
                cout << " ";
        }
        cout << "\n";
        n--;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern140.py"
height = 5
width = 2 * height - 1
n = width // 2
for i in range(0, height):
    for j in range(0, width + 1):
        if j == n or j == (width - n) or (i == (height // 2) and n < j < (width - n)):
            print("*", end="")
        else:
            print(end=" ")
    print()
    n = n - 1
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
