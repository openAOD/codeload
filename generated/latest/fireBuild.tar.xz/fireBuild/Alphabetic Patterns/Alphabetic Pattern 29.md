---
title: Alphabetic Pattern 29
---

# Alphabetic Pattern 29

![Alphabetic Pattern 29](/assets/patterns/alphabetic/alphabeticpattern29.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern29.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {
    
    for (int j=0;j<=4;j++)            //outer 5 iterations
    {   
        int k= j;
        while(k)                      //loop for number of spaces, no.of spaces at jth iteration would be |4-j|
        {
            cout << "  ";
            k--;
        }
        for (int i=0;i<=(4-j);i++)          //loop to print  jth  character (5-j) times in each iteration
        {                               
            char x = (char) j+65;       
            cout << x << " ";
        }
       cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
