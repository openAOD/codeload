---
title: Alphabetic Pattern 143
---

# Alphabetic Pattern 143

![Alphabetic Pattern 143](/assets/patterns/alphabetic/alphabeticpattern143.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern143.cpp"
#include <iostream>
using namespace std;

int main(){

int i, j,height=5;
    for (i = 0; i < height; i++) {
        cout <<"*";
        for (j = 0; j < height; j++) {
            if ((i == 0 || i == height - 1)
                && j < height - 1)
                cout <<"*";
            else if (j == height - 1 && i != 0
                    && i != height - 1)
                cout <<"*";
            else
                cout <<" ";
        }
        cout <<"\n";
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern143.py"
height = 5
for i in range(0, height):
    print("*", end="")
    for j in range(0, height):
        if ((i == 0 or i == height - 1) and j < height - 1):
            print("*", end="")
        elif (j == height - 1 and i != 0 and i != height - 1):
            print("*", end="")
        else:
            print(end=" ")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
