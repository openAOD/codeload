---
title: Alphabetic Pattern 58
---

# Alphabetic Pattern 58

![Alphabetic Pattern 58](/assets/patterns/alphabetic/alphabeticpattern58.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern58.java"
/**
 * 
 * pattern to be printed 
 * 
 *  A * * * *
 *  B B * * *
 *  C C C * *
 *  D D D D *
 *  E E E E E
 * 
 * 
 * alphabeticpattern58
 */
public class alphabeticpattern58 {

    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern58(rows);
    }

    private static void alphabetPattern58(int n) {

        int alphabet = 64;
        for (int i = n; i >= 1; i--) {
            for (int j = 0; j <= n-i; j++) {
                System.out.print((char) (alphabet +n-i+1) + " ");
            }
            for (int j = n-i+1; j < n; j++) {
                System.out.print( "* "); 
            }
            System.out.println();
        }

    }
}


```
