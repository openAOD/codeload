---
title: Alphabetic Pattern 64
---

# Alphabetic Pattern 64

![Alphabetic Pattern 64](/assets/patterns/alphabetic/alphabeticpattern64.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern64.java"
/**
 * 
 * 
 * pattern to be printed
 * 
 *  E E E E E
 *  * D D D D
 *  * * C C C
 *  * * * B B
 *  * * * * A
 * 
 * alphabeticpattern64
 */
public class alphabeticpattern64 {
    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern64(rows);
    }

    private static void alphabetPattern64(int n) {

        int alphabet = 64;
        for (int i = n; i >= 1; i--) {
            for (int j = 1; j <= n- i; j++) {
                System.out.print("* ");
            }
            for (int j = n-i; j <n ; j++) {
                System.out.print((char) (alphabet + i) + " ");
            }
            System.out.println();
        }

    }
}
```
