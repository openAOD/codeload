---
title: Alphabetic Pattern 2
---

# Alphabetic Pattern 2

![Alphabetic Pattern 2](/assets/patterns/alphabetic/alphabeticpattern2.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern2.cpp"
#include <iostream>
using namespace std;

int main() {
    
    
    for(int i=0;i<5;i++)
    {
          for(char j='A';j<='E';j++)
        {
            cout<<j<<" ";
        }
        
        cout<<"\n";
    }
      

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern2.py"
print("Enter the no of rows: ")
n = int(input())
for i in range(1, n+1):
    for j in range(1, n+1):
        print(chr(j+64), end=" ")
    print()
```
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern2.java"
// program to print following pattern
// A B C D E
// A B C D E
// A B C D E
// A B C D E
// A B C D E

public class alphabeticpattern2 {

    public static void main(String[] args) {

        int rows = 5;
        alphabet_rectangle(rows);
    }
    static void alphabet_rectangle(int n){

        int alphabet = 65;
        for (char i = 0 ; i < n ; i++) {
            for (char j = 0 ; j < n ; j++) {
                System.out.print((char)(alphabet + j) + " ");
            }
            System.out.println();
        }
    }
}
```
