---
title: Alphabetic Pattern 56
---

# Alphabetic Pattern 56

![Alphabetic Pattern 56](/assets/patterns/alphabetic/alphabeticpattern56.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern56.cpp"
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int cur_char=4; //(A+4 =E)
    for (int i=0;i<5;i++)
    {
        int inc=0;
        for (int j=i;j<i+5;j++)
        {
            inc=j;
            if(inc>cur_char)
            inc=inc-cur_char-1;                       //if char is > E , char is A
            char a = 65+inc;
            cout << a << " ";
        }
        cout << "\n";
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern56.java"
/**
 * 
 * pattern tpo be printed
 * 
 * A B C D E
 * B C D E A
 * C D E A B
 * D E A B C
 * E A B C D
 * 
 * alphabeticpattern56
 */
public class alphabeticpattern56 {

    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern56(rows);
    }

    private static void alphabetPattern56(int n) {

        int alphabet = 64;
        for (int i = n; i >= 1; i--) {
            for (int j = 0; j < i; j++) {
                System.out.print((char) (alphabet + n - i + 1 + j) + " ");
            }
            for (int j = i; j < n; j++) {
                System.out.print((char) (alphabet - i + 1 + j) + " ");
            }
            System.out.println();
        }

    }
}
```
