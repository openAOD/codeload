---
title: Alphabetic Pattern 35
---

# Alphabetic Pattern 35

![Alphabetic Pattern 35](/assets/patterns/alphabetic/alphabeticpattern35.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern35.cpp"
#include<bits/stdc++.h>
//#include<iostream>
using namespace std;
int main(){
    for(int i=0;i<5;i++){   //for 5 lines of output i is 5
        int k=i;
        while (k--)         //for spaces before first character
        {
            cout<<" ";
        }
        
        for (int j = 0; j < 5-i; j++)
        {
            char a=65+j;
            cout<<a<<" ";
        }
        cout<<endl;
    }
 return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern35.java"
//pattern to be printed
//A B C D E
// A B C D
//  A B C
//   A B
//    A

/**
 * alphabeticpattern35
 */
public class alphabeticpattern35 {
    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern35(rows);
    }

    private static void alphabetPattern35(int n) {

        int alphabet = 64;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < n-i; j++) {
            System.out.print((char)(alphabet+j+1)+" ");    
            }
            System.out.println();
        }
    }

}

```
