---
title: Alphabetic Pattern 13
---

# Alphabetic Pattern 13

![Alphabetic Pattern 13](/assets/patterns/alphabetic/alphabeticpattern13.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern13.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {
    
    for (int j=0;j<5;j++)
    {
        for (int i=j;i>=0;i--)
        {
            char x = (char) i+65;
            cout << x << " ";
        }
       cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern13.py"
size = int(input("Enter Number of Rows:  "))
for i in range(0, size):
    for j in range(65 + i, 64, -1):
        a = chr(j)
        print(a, end="")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
