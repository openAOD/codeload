---
title: Alphabetic Pattern 9
---

# Alphabetic Pattern 9

![Alphabetic Pattern 9](/assets/patterns/alphabetic/alphabeticpattern9.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern9.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {
    
    for (int j=1;j<=5;j++)
    {
        for (int i=1;i<j+1;i++)
        {
            char x = (char) (j-1)+65;
            cout << x << " ";
        }
       cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern9.java"
// program to print following pattern
// A
// B B
// C C C
// D D D D
// E E E E E

public class alphabeticpattern9 {

    public static void main(String[] args) {

        int rows = 6;
        alphabet_rectangle(rows);
    }
    static void alphabet_rectangle(int n){

        int alphabet = 64;
        for (char i = 0 ; i < n ; i++) {
            for (char j = 1 ; j <= i ; j++) {
                System.out.print((char)(alphabet) + " ");
            }
            alphabet++;
            System.out.println();
        }
    }
}
```
