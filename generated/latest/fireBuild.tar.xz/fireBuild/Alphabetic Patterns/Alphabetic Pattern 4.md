---
title: Alphabetic Pattern 4
---

# Alphabetic Pattern 4

![Alphabetic Pattern 4](/assets/patterns/alphabetic/alphabeticpattern4.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern4.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {
    
    for(int j=0;j<5;j++)
    {
    for(char i='E';i>='A';i--)
    {
          
            cout<<i << " " ;
    }
        
        cout<< "\n";
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern4.java"
// program to print following pattern
// E D C B A
// E D C B A
// E D C B A
// E D C B A
// E D C B A

public class alphabeticpattern4 {

    public static void main(String[] args) {

        int rows = 5;
        alphabet_rectangle(rows);
    }
    static void alphabet_rectangle(int n){

        int alphabet = 64;
        for (char i = (char) n; i > 0 ; i--) {
            for (char j = (char) n; j > 0 ; j--) {
                System.out.print((char)(alphabet + j) + " ");
            }
            System.out.println();
        }
    }
}
```
