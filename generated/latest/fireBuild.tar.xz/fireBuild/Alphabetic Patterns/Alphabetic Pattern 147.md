---
title: Alphabetic Pattern 147
---

# Alphabetic Pattern 147

![Alphabetic Pattern 147](/assets/patterns/alphabetic/alphabeticpattern147.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern147.cpp"
#include <iostream>
using namespace std;

int main()
{
    int i, j;
    int height = 5;
    for (i = 0; i < height; i++)
    {
       cout<<"*";
        for (j = 0; j < height; j++)
        {
            if ((j == height - 1) || (i == height / 2))
                cout<<"*";
            else
                cout<<" ";
        }
       cout<<endl;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern147.py"
height = 5
for i in range(0, height):
    print("*", end="")
    for j in range(0, height):
        if ((j == height - 1) or (i == height // 2)):
            print("*", end="")
        else:
            print(end=" ")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
