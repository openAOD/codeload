---
title: Alphabetic Pattern 6
---

# Alphabetic Pattern 6

![Alphabetic Pattern 6](/assets/patterns/alphabetic/alphabeticpattern6.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern6.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {
    

    for (int j=0;j<5;j++)
    {
        for(char i='A';i<='E';i++)
        { 
            char x= char(i+j);
            cout<< x <<" ";

        }
        cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern6.py"
print("Enter the no of rows: ")
n = int(input())
k = 1
for i in range(0, n):
    for j in range(1, n+1):
        k = i + j
        print(chr(k+64), end=" ")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
