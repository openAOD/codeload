---
title: Alphabetic Pattern 28
---

# Alphabetic Pattern 28

![Alphabetic Pattern 28](/assets/patterns/alphabetic/alphabeticpattern28.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern28.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {
    
    for (int j=4;j>=0;j--)            //outer 5 iterations
    {   
        int k= 4-j;
        while(k)                      //loop for number of spaces, no.of spaces at jth iteration would be |4-j|
        {
            cout << "  ";
            k--;
        }
        for (int i=0;i<=j;i++)          //loop to print first j+1 characters in each iteration
        {
            char x = (char) i+65;
            cout << x << " ";
        }
       cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
