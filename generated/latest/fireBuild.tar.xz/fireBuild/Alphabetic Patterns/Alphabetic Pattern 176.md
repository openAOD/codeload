---
title: Alphabetic Pattern 176
---

# Alphabetic Pattern 176

![Alphabetic Pattern 176](/assets/patterns/alphabetic/alphabeticpattern176.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern176.cpp"
#include <iostream>
using namespace std;

int main()
{
    int height = 5;
    int i, j, half = height / 2, dummy = half;
    for (i = 0; i < height; i++)
    {
        cout << "K";
        for (j = 0; j <= half; j++)
        {
            if (j == abs(dummy))
                cout << "K";
            else
                cout << " ";
        }
        cout << "\n";
        dummy--;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern176.py"
height = 5
half = height // 2
dummy = half
for i in range(0, height):
    print("K", end="")
    for j in range(0, half+1):
        if (j == abs(dummy)):
            print("K", end="")
        else:
            print(end=" ")
    print()
    dummy = dummy - 1
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
