---
title: Alphabetic Pattern 3
---

# Alphabetic Pattern 3

![Alphabetic Pattern 3](/assets/patterns/alphabetic/alphabeticpattern3.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern3.cpp"
#include <iostream>
using namespace std;

int main() {
    
    
    for(char i='E';i>='A';i--)
    {
          for(int j=0;j<5;j++)
        {
            cout<<i<<" ";
        }
        
        cout<<"\n";
    }
      

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern3.py"
print("Enter the no of rows: ")
n = int(input())
for i in range(n, 0, -1):
    for j in range(n, 0, -1):
        print(chr(i+64), end=" ")
    print()
```
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern3.java"
// program to print following pattern
// E E E E E
// D D D D D
// C C C C C
// B B B B B
// A A A A A

public class alphabeticpattern3 {
    public static void main(String[] args) {

        int rows = 5;
        alphabet_rectangle(rows);
    }
    static void alphabet_rectangle(int n){

        int alphabet = 64;
        for (char i = (char) (n); i > 0 ; i--) {
            for (char j = (char) (n); j > 0 ; j--) {
                System.out.print((char)(alphabet + i) + " ");
            }
            System.out.println();
        }
    }
}
```
