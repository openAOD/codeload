---
title: Alphabetic Pattern 186
---

# Alphabetic Pattern 186

![Alphabetic Pattern 186](/assets/patterns/alphabetic/alphabeticpattern186.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern186.cpp"
#include <iostream>
using namespace std;

int main()
{
    int n = 6;
    for (int i = 0; i < n; i++)
    {
        if (i != 0 && i != n - 1)
        {
            cout << "U";
        }
        else
        {
            cout << " ";
        }
        for (int j = 0; j < n; j++)
        {
            if (((i == n - 1) && j >= 0&& j < n - 1))
            {
                cout << "U";
            }
            else if (j == n - 1 && i != 0 && i != n - 1)
            {
                cout << "U";
            }
            else
            {
                cout << " ";
            }
        }
        cout << endl;
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
