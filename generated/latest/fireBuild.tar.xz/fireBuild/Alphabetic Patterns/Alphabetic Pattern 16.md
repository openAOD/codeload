---
title: Alphabetic Pattern 16
---

# Alphabetic Pattern 16

![Alphabetic Pattern 16](/assets/patterns/alphabetic/alphabeticpattern16.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern16.cpp"
#include <iostream>
using namespace std;

int main()
{
    int count=5;
    
    for(char i='E';i>='A';i--)
    {
        for(int j=0;j<count;j++)
        {
            cout<<i<<" ";
        }
        
        count--;
        
        cout<<"\n";
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern16.py"
size = int(input("Enter Number of Rows:  "))
for i in range(65+size -1, 64, -1):
    for j in range(64, i):
        a = chr(i)
        print(a, end="")
    print()
```
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern16.java"
// program to print following pattern
// E E E E E
// D D D D
// C C C
// B B
// A

public class alphabeticpattern16 {

    public static void main(String[] args) {

        int rows = 5;
        alphabet_triangle(rows);
    }
    static void alphabet_triangle(int n){

        int alphabet = 64;
        for (char i = (char) (n); i > 0 ; i--) {
            for (char j = 1 ; j <= i ; j++) {
                System.out.print((char)(alphabet + i) + " ");
            }
            System.out.println();
        }
    }
}
```
