---
title: Alphabetic Pattern 146
---

# Alphabetic Pattern 146

![Alphabetic Pattern 146](/assets/patterns/alphabetic/alphabeticpattern146.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern146.cpp"
#include <iostream>
using namespace std;

int main(){
    int i, j;
    int height = 5;
    int width = 2*height-1;
    width--;
    for (i = 0; i < height; i++) {
        for (j = 0; j < width; j++) {
            if ((i == 0 || i == height - 1)
                && (j == 0 || j == width - 1))
                cout <<" ";
            else if (j == 0)
                cout <<"*";
            else if (i == 0 && j <= height)
                cout <<"*";
            else if (i == height / 2
                    && j > height / 2)
                cout <<"*";
            else if (i > height / 2
                    && j == width - 1)
                cout <<"*";
            else if (i == height - 1
                    && j < width)
                cout <<"*";
            else
                cout <<" ";
        }
        cout <<"\n";
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern146.py"
height = 5
width = (2 * height) - 1
for i in range(0, height):
    for j in range(0, width-1):
        if ((i == 0 or i == height - 1) and (j == 0 or j == width - 2)):
            print(end=" ")
        elif (j == 0):
            print("*", end="")
        elif (i == 0 and j <= height):
            print("*", end="")
        elif (i == height // 2 and j > height // 2):
            print("*", end="")
        elif (i > height // 2 and j == width - 2):
            print("*", end="")
        elif (i == height - 1 and j < width - 1):
            print("*", end="")
        else:
            print(end=" ")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
