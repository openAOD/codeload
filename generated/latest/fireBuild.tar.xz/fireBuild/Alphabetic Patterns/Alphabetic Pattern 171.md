---
title: Alphabetic Pattern 171
---

# Alphabetic Pattern 171

![Alphabetic Pattern 171](/assets/patterns/alphabetic/alphabeticpattern171.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern171.py"
height = 5
for i in range(0, height):
    print("F", end="")
    for j in range(0, height):
        if ((i == 0) or (i == height // 2 and j <= height // 2)):
            print("F", end="")
        else:
            continue
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
