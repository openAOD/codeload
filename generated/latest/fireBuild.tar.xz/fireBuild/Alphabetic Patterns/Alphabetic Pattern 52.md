---
title: Alphabetic Pattern 52
---

# Alphabetic Pattern 52

![Alphabetic Pattern 52](/assets/patterns/alphabetic/alphabeticpattern52.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern52.cpp"
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int max=4; //(A+3=D hence max is 4) 
    int current_char=0; //starts from A
    for (int i=1;i<=max;i++)
    {
        for (int l=1;l<=max-i;l++)
        cout << "  ";                // for spaces
        for (int j=1;j<=i;j++)
        {
            char a=65+current_char;    //print current char, row number of times
            cout << a << " ";
        }
        current_char+=1;          //update current character, as it changes in the next row
        cout << "\n";
    }
    //once you reach max then we go from max-1 to 1 char in row
    for (int i=max-1;i>=1;i--)
    {
        for (int l=1;l<=max-i;l++)
        cout << "  "; 
         for (int j=1;j<=i;j++)
        {
            char a=65+current_char;    //print current char, row number of times
            cout << a << " ";
        }
        current_char+=1;          //update current character, as it changes in the next row
        cout << "\n";
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern52.java"
/**
 * 
 * pattern to be printed 
 * 
 *        A
 *      B B
 *    C C C
 *  D D D D
 *    E E E 
 *      F F
 *        G
 * alphabeticpattern52
 */
public class alphabeticpattern52 {


    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern51(rows);
    }

    private static void alphabetPattern51(int n) {

        int alphabet = 64;
        for (int i = n; i >= 1; i--) {
            for (int j = 1; j < i; j++) {
                System.out.print("  ");
            }
            for (int j = 1; j <= n - i; j++) {
                System.out.print((char) (alphabet+n-i) + " ");
            }
            System.out.println();
        }
        for (int i = n - 2; i >= 1; i--) {
            for (int j = 1; j <n- i; j++) {
                System.out.print("  ");
            }
            for (int j = 1; j <= i; j++) {
                System.out.print((char) (alphabet+2*n-i-2) + " ");
            }
            System.out.println();
        }

    }
}


```
