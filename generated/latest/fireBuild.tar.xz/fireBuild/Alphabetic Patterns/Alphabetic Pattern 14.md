---
title: Alphabetic Pattern 14
---

# Alphabetic Pattern 14

![Alphabetic Pattern 14](/assets/patterns/alphabetic/alphabeticpattern14.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern14.cpp"
#include <iostream>
using namespace std;

int main()
{
    int count=5;
    
    for(char i='A';i<='E';i++)
    {
        for(int j=0;j<count;j++)
        {
            cout<<i<<" ";
        }
        
        count--;
        
        cout<<"\n";
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern14.py"
size = int(input("Enter Number of Rows:  "))
for i in range(65, 65+size):
    for j in range(i, 65+size):
        a = chr(i)
        print(a, end="")
    print()
```
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern14.java"
// program to print following pattern
// A A A A A
// B B B B
// C C C
// D D
// E

public class alphabeticpattern14 {

    public static void main(String[] args) {

        int rows = 5;
        alphabet_triangle(rows);
    }
    static void alphabet_triangle(int n){

        int alphabet = 65;
        for (char i = 0 ; i <= n ; i++) {
            for (char j = i ; j < n ; j++) {
                System.out.print((char)(alphabet) + " ");
            }
            alphabet++;
            System.out.println();
        }
    }
}
```
