---
title: Alphabetic Pattern 144
---

# Alphabetic Pattern 144

![Alphabetic Pattern 144](/assets/patterns/alphabetic/alphabeticpattern144.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern144.cpp"

#include <iostream>
using namespace std;

int main()
{

    int i, j, height = 5;
    for (i = 0; i < height; i++)
    {
        cout << "* ";
        for (j = 0; j < height; j++)
        {
            if ((i == 0 || i == height - 1) || (i == height / 2  && j <= height / 2))
                cout << "* ";
            else
                continue;
        }
        cout << "\n";
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern144.py"
height = 5
for i in range(0,height) :
        print("*",end="")
        for j in range(0,height) :
            if ( (i == 0 or i == height - 1) or (i == height // 2 and j <= height // 2) ):
                print("*",end="")
            else :
                continue
        print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
