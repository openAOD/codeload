---
title: Alphabetic Pattern 21
---

# Alphabetic Pattern 21

![Alphabetic Pattern 21](/assets/patterns/alphabetic/alphabeticpattern21.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern21.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {
    
    int count=0;
    for (int j=0;j<5;j++)  // for 5iterations
    {
        for (int i=0;i<=j;i++)   //limiting value at each step
        {
            char x = (char) count+65; //change number to char
            cout << x << " ";
            count+=1;   //for next alphabet
        }
       cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
