---
title: Alphabetic Pattern 168
---

# Alphabetic Pattern 168

![Alphabetic Pattern 168](/assets/patterns/alphabetic/alphabeticpattern168.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern168.cpp"
#include <iostream>
using namespace std;

int main()
{
    int i, j, height = 5;
    for (i = 0; i < height; i++)
    {
        cout << "C";
        for (j = 0; j < (height - 1); j++)
        {
            if (i == 0 || i == height - 1)
                cout << "C";
            else
                continue;
        }
        cout << "\n";
    }
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern168.py"
height = 5
for i in range(0, height):
    print("*", end="")
    for j in range(0, height - 1):
        if i == 0 or i == height - 1:
            print("*", end="")
        else:
            continue
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
