---
title: Alphabetic Pattern 179
---

# Alphabetic Pattern 179

![Alphabetic Pattern 179](/assets/patterns/alphabetic/alphabeticpattern179.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern179.py"
height = 5
counter = 0
for i in range(0, height):
    print("N", end="")
    for j in range(0, height+1):
        if (j == height):
            print("N", end="")
        elif (j == counter):
            print("N", end="")
        else:
            print(end=" ")
    counter = counter + 1
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
