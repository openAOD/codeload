---
title: Alphabetic Pattern 145
---

# Alphabetic Pattern 145

![Alphabetic Pattern 145](/assets/patterns/alphabetic/alphabeticpattern145.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern145.py"
height = 5
for i in range(0, height):
    print("*", end="")
    for j in range(0, height):
        if ((i == 0) or (i == height // 2 and j <= height // 2)):
            print("*", end="")
        else:
            continue
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
