---
title: Alphabetic Pattern 38
---

# Alphabetic Pattern 38

![Alphabetic Pattern 38](/assets/patterns/alphabetic/alphabeticpattern38.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern38.cpp"
#include<bits/stdc++.h>
//#include<iostream>
using namespace std;
int main(){
    for(int i=0;i<5;i++){   
        int k=4-i;
        while (k--)         //for spaces before first character
        {
            cout<<"  ";
        }
        
        for (int j = 0; j < 2*i+1; j++)
        {
            char a=65+j;
            cout<<a<<" ";
        }
        cout<<endl;
    }
 return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern38.py"
n = int(input("Enter number of rows : "))
for i in range(n):
    for j in range(n - i - 1):
        print(' ', end='')
    for k in range(2 * i + 1):
        print(chr(65 + k), end='')
    print()
```
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern38.java"
//    A
//   ABC
//  ABCDE
// ABCDEFG
//ABCDEFGI


/**
 * alphabeticpattern38
 */
public class alphabeticpattern38 {

    public static void main(String[] args) {

        int rows = 6;
        alphabetPattern38(rows);
    }

    private static void alphabetPattern38(int n) {

        int alphabet = 64;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < 2*i-1; j++) {
                
                 System.out.print((char) (alphabet + j+1));
            }
            System.out.println();
        }
    
    }
}
```
