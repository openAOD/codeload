---
title: Alphabetic Pattern 32
---

# Alphabetic Pattern 32

![Alphabetic Pattern 32](/assets/patterns/alphabetic/alphabeticpattern32.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern32.cpp"
#include <iostream>
using namespace std;

int main()
{

    for(int i = 0; i < 5; i++)           //outer 5 iterations
    {
        for(int k= 1; k<5-i;k++)         //no.of gaps at start of ith iteration 4-i
            cout <<" ";

        for(int j = 0; j <= i; j++)     // i+1 th character i times
        {
            char x =(char)j+65;
            cout << x << " ";           //add space after every value
        }
        cout << endl;
    }
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern32.py"
num=int(input("Enter Number of Rows:"))
for i in range(65, 65+num):
    for j in range(75+num, i, -1):
        print(" ", end="")
    for k in range(65, i+1):
        a = chr(k)
        print(a, end=" ")
    print()
```
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern32.java"
//pattern to be printed
//    A
//   A B
//  A B C 
// A B C D
//A B C D E


/**
 * alphabeticpattern32
 */
public class alphabeticpattern32 {
public static void main(String[] args) {
    int rows = 6;
    alphabetPattern32(rows);
}
private static void alphabetPattern32(int n) {

    int alphabet = 64;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j <n-i; j++) {
            System.out.print(" ");
        }
        for (int j = 0; j < i; j++) {
        System.out.print((char)(alphabet+j+1)+" ");    
        }
        System.out.println();
    }
}

}
    

```
