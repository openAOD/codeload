---
title: Alphabetic Pattern 24
---

# Alphabetic Pattern 24

![Alphabetic Pattern 24](/assets/patterns/alphabetic/alphabeticpattern24.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern24.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {

    
    for (int j=0;j<5;j++)            //outer 5 iterations
    {   
        int k= 4-j;
        while(k)                      //loop for number of spaces, no.of spaces at jth iteration would be |j-4|
        {
            cout << "  ";
            k--;
        }
        for (int i=j;i>=0;i--)          //loop to print first j characters in each iteration in reverse direction
        {
            char x = (char) i+65;
            cout << x << " ";
        }
       cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern24.py"
num=int(input("Enter Number of Rows:"))
for i in range(65, 64+num+1):
    for j in range(64+num, 64, -1):
        if(j <= i):
            a = chr(j)
            print(a, end="")
        else:
            print(" ", end="")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
