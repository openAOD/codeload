---
title: Alphabetic Pattern 141
---

# Alphabetic Pattern 141

![Alphabetic Pattern 141](/assets/patterns/alphabetic/alphabeticpattern141.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern141.cpp"
#include <iostream>
using namespace std;

int main()
{
    int height = 5;
    int width = (2 * height) - 1;
    int i, j, half = (height / 2);
    for (i = 0; i < height; i++)
    {
        cout << "*";
        for (j = 0; j < width; j++)
        {
            if ((i == 0 || i == height - 1 || i == half) && j < (width - 2))
                cout << "*";
            else if (j == (width - 2) && !(i == 0 || i == height - 1 || i == half))
                cout << "*";
            else
                cout << " ";
        }
        cout << "\n";
    }

    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern141.py"
height = 5
width = 2 * height - 1
half = height // 2

for i in range(0, height):
    print("*", end="")
    for j in range(0, width):
        if (i == 0 or i == height - 1 or i == half) and j < (width - 2):
            print("*", end="")
        elif j == (width - 2) and not (i == 0 or i == height - 1 or i == half):
            print("*", end="")
        else:
            print(end=" ")
    print()
```
## Java
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
