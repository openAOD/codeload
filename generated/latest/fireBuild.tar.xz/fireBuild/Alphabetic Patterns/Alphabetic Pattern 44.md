---
title: Alphabetic Pattern 44
---

# Alphabetic Pattern 44

![Alphabetic Pattern 44](/assets/patterns/alphabetic/alphabeticpattern44.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern44.cpp"
#include<bits/stdc++.h>
using namespace std;
int main(){
    for(int i=4;i>=0;i--){    //for reverse order (E to A)
        int k=4-i;
        while (k--)         //for spaces before first character
        {
            cout<<"  ";
        }
        
        for (int j = 0; j < 2*i+1; j++) //odd number of chars at each row
        {
            char a=65+2*i;                 // the character at each row
            cout<<a<<" ";
        }
        cout<<endl;
    }
 return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern44.java"
/**
 * 
 * pattern to be printed 
 * 
 *  IIIIIIIIII
 *   GGGGGGG
 *    EEEEE
 *     CCC
 *      A
 * 
 * alphabeticpattern44
 */
public class alphabeticpattern44 {
    public static void main(String[] args) {

        int rows = 5;
        alphabetPattern44(rows);
    }

    private static void alphabetPattern44(int n) {

        int alphabet = 64;
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print("  ");
            }
            for (int k = 1; k <= 2*(n - i)-1 ; k++) {
                System.out.print((char)(alphabet+(2*n-1)-2*i) + " ");
            }
            System.out.println();
        }

}
}

```
