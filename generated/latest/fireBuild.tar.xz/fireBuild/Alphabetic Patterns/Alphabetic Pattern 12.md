---
title: Alphabetic Pattern 12
---

# Alphabetic Pattern 12

![Alphabetic Pattern 12](/assets/patterns/alphabetic/alphabeticpattern12.PNG)
## C
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## C++
```cpp title="./Assets/patterns/alphabetic/alphabeticpattern12.cpp"
#include <bits/stdc++.h>
using namespace std;

int main() {
    
    for (int j=4;j>=0;j--)
    {
        for (int i=5;i>=j+1;i--)
        {
            char x = (char) j+65;
            cout << x << " ";
        }
       cout << "\n";
    }
        
    return 0;
}
```
## CSharp
:::tip
We are currently awaiting contributions on this pattern for this language. Please check back later or contribute to this pattern.
:::
## Python
```python title="./Assets/patterns/alphabetic/alphabeticpattern12.py"
size = int(input("Enter Number of Rows:  "))
for i in range(65+size, 64, -1):
    for j in range(65+size, i, -1):
        a = chr(i)
        print(a, end="")
    print()
```
## Java
```java title="./Assets/patterns/alphabetic/alphabeticpattern12.java"
// program to print following pattern
// E
// D D
// C C C
// B B B B
// A A A A A

public class alphabeticpattern12 {

    public static void main(String[] args) {

        int rows = 5;
        alphabet_triangle(rows);
    }
    static void alphabet_triangle(int n){

        int alphabet = 64;
        for (char i = (char) (n); i > 0 ; i--) {
            for (char j = (char) (n); j >=i ; j--) {
                System.out.print((char)(alphabet + i) + " ");
            }
            System.out.println();
        }
    }
}
```
